---
name: vexon-reel-editor
description: Edit raw clips into a branded 9:16 Instagram/TikTok reel for VEXON (Vexon Med) in the editing style of a reference reel - analyse the reference, storyboard first, then render beat-synced kinetic typography, motion-graphic callouts and transitions with ffmpeg + Python. Use when the user uploads raw footage plus a brief (on-screen lines, CTA) and/or a reference TikTok/Reel link and asks for a reel, short, or social video edit, or asks to revise one made this way.
---

# VEXON reel editor

Turns raw phone clips + a brief + a reference reel into a finished vertical reel in the approved VEXON
house style. Everything is rendered by `scripts/render_reel.py` from a **plan JSON**, so every revision is
a small plan edit plus a re-render.

The approved reference build is `examples/longevity_assessment.plan.json`, the "Why get a longevity
assessment?" reel (v6). Start new reels by copying it.

## Requirements
`ffmpeg`/`ffprobe`, Python 3 with `numpy` + `Pillow`, and `yt-dlp` for downloading references (the script
installs it if missing). The brand fonts Oswald and Public Sans are bundled in `assets/fonts/` (both OFL).

## Workflow

### 1. Gather inputs
- **Raw clips:** any orientation; `.MOV` rotation metadata is handled automatically.
- **Brief:** the hook question, the lines that appear one at a time, and the CTA.
- **Brand sheet:** the defaults are in `references/style-guide.md`. Only override them if the user gives new ones.
- **Reference reel URL (optional):** its editing techniques are copied, never its content or its audio.
- **Song:** see the "Music" section below.

### 2. Analyse the reference (if one is given)
```bash
scripts/analyze_reference.sh "<url>" <work>/ref
```
1. Read `sheet*.jpg`, `open.jpg` and the strips in `cuts/`.
2. Write down the techniques: cut rhythm, transitions, title treatment, framing, grade and montage pacing.
3. Map each technique to the renderer's vocabulary (see `references/style-guide.md`, "Technique catalogue").
4. Tell the user, in plain language, which techniques you found.

### 3. Inspect the raw clips
```bash
scripts/inspect_clips.sh <work>/clips clip1 clip2 ...
scripts/grid_frame.sh <clip> <sec> <out.png> [cx] [cy] [rot]
```
`inspect_clips.sh` makes timecoded contact sheets. `grid_frame.sh` shows the output framing with a pixel
grid, so you can read off callout boxes, ring centres and text positions.

Watch for:
- **Mid-clip rotation:** the phone turned sideways part-way through. Set `"rot": true` and only use that time range.
- **Shot changes inside a clip:** the first frame must be the intended shot. Nudge `ss` if it isn't (the v6 hook needed 4.9 → 5.25).
- **Short sections:** a shot's source length is `dur × speed`; keep it inside a single continuous section of the clip.

### 4. Write the plan, then STORYBOARD FIRST
1. Copy the example plan.
2. Set `sources`, `bpm` and the shots, then fill in the brief text verbatim, with corrected grammar and punctuation.
3. Render the storyboard:
   ```bash
   python3 scripts/storyboard.py plan.json <work>/storyboard.png
   ```
4. Send the storyboard to the user before doing the full render. The user explicitly asks for a storyboard first.

### 5. Render, check, deliver
```bash
python3 scripts/render_reel.py plan.json <work>/render.mp4          # ~5 min for 30 s; run in background
python3 scripts/render_reel.py plan.json <work>/s --stills 2.0,12.0  # fast spot checks
scripts/finalize.sh <work>/render.mp4 /path/Deliverable.mp4 [licensed_audio] [offset]
```
- Before re-rendering, check changed sections with `--stills`.
- After rendering, sample frames from the output (e.g. a ffmpeg `select=...,tile` contact strip) and look at them before you send anything.
- Deliver with a short note: what changed, what's left, and anything the user must do (add music, add logo).

## Green-screen / talking-head reels
Use this when the user supplies a presenter clip ("green screen style"). The approved build is
`examples/vo2_greenscreen.plan.json` (Marina, "Think your Apple Watch knows your VO2 max?").
The talking-head video does **not** need a real green screen: it is matted with AI segmentation.

1. **Transcribe** for captions and cut points: `scripts/transcribe_words.py voice.wav words.json`
   (openai-whisper; Hugging Face may be blocked, the OpenAI model host works).
2. **Matte** the presenter: `scripts/matte_talent.py clip.mov <work>/matte` (Robust Video Matting, ~1 fps on CPU,
   run in background), then `scripts/clean_matte.py <work>/matte` to drop furniture fragments and print the
   head-top y per second. Check a few frames over orange before going on.
3. **Plan:** shots take `"sec"` (seconds) instead of bars, cut on her phrase boundaries; b-roll per line matches
   what she says. Top-level keys:
   - `talent`: `{frames, start (source s at output 0), scale (1.5 maps a 720x1280 clip to full frame), x, y,
     until, shadow, wrap}`. Talent sits above footage/callouts and below type.
   - `captions`: `[{t0, t1, text, highlight}]` in output seconds (source - start). 2-6 words a page, rendered in the
     house kinetic style (Oswald caps, orange box on key words). `caption_style.bottom` keeps the block above her
     head (head top >= 750 at scale 1.5, so bottom 712).
   - Per shot `pan: [px, py]`: where the crop window sits after zoom. `z ~1.15-1.35` with `py 1.0` lifts the
     subject's face into the visible band above the talent.
   - `"tin": "dissolve"` on the end slot: 1 s blur-dissolve from the presenter into the clean slot; `glow` adds a faint
     centre glow (e.g. `#223450`) where the client places the logo.
   - `look.hit_strength` / `look.flash_strength` (0-1) tone transitions down; `beat_pulse: false` for speech-led edits.
   - `" | "` inside a text forces a line break (keep highlighted phrases on one line).
4. **Text discipline:** captions carry the message; keep only 1-2 kinetic moments (hook slam title synced to her words,
   CTA) and at most one callout. Never put text over her face or body.
5. **Audio:** her voice is the soundtrack (highpass, light denoise/compression, loudnorm). Music must be subtle:
   `scripts/music_bed.py` synthesises an original bed; normalise it to about -29 LUFS, sidechain-duck it under the
   voice, master to about -14 LUFS, then mux with the render.

## Plan format (one entry per shot, played in order)

| key | meaning |
|---|---|
| `src` / `ss` | Source key from `sources` (or `null` for a solid end slot) and its start time in seconds. |
| `bars` or `beats` | Shot length on the beat grid. One bar is 4 beats; at 140 BPM a bar is 1.714 s. |
| `kind` | `title`, `line` (the default when `text` is set), `cta`, `burst` (fast montage), `plain`, or `end`. |
| `tin` | Transition into this shot: `cut`, `flash`, `cutout`, `whip`, `panels`, `punch`, or `hit` (montage). |
| `z` | Zoom at the start and end of the shot, e.g. `[1.0, 1.1]` for a push-in. A beat pulse is added automatically. |
| `cx`, `cy` | Crop anchor (0–1) when the source is wider or taller than 9:16. |
| `speed` | Playback speed. Below 1 is slow-mo. |
| `bright` | Grade brightness offset. |
| `rot` | Rotate sideways footage back to upright. |
| `text`, `highlight` | The on-screen line and the key words that get the orange box. |
| `ty`, `size` | Text centre y position and font size. Defaults are 1130 and an automatic size. |
| `num`, `num_y` | Giant outlined number behind the line (e.g. `"03"`) and its y position. Keep it clear of the text. |
| `text_span: 2` + `cont: true` on the next shot | Hold one line of text across two shots. |
| `fx` | Callout: `{"kind":"brackets"\|"scan","box":[x0,y0,x1,y1],"tag":"..."}` or `{"kind":"rings","c":[x,y],"tag":"..."}`. |
| `title_words` | For the hook: a list of `{text, beat, size, y, color}`. |
| `note` | Caption shown on the storyboard. |

Top-level keys:
- `bpm`, `fps`, `size`.
- `look`, with the flags `grade`, `grain`, `beat_pulse` and `card_border`. **Leave `card_border` false.**
- `brand_colors`, used only to override the defaults.
- `title`, `music_note` (both shown on the storyboard).

## Music
Never download, rip or embed copyrighted songs, including ones the user names, such as "Band4Band".
Instead:
1. Cut the edit to the song's tempo by setting `bpm`. Each shot is a whole number of bars and the montage uses 8th notes.
2. Export without sound (silent audio track) using `finalize.sh`.
3. Tell the user to add the sound in the app, starting it on a downbeat. Mention that business accounts are often limited to the Commercial Music Library.

If the user supplies an audio file they have rights to, pass it to `finalize.sh` with an offset.

## House rules (learned from client feedback, do not regress)
See `references/style-guide.md` → "Client feedback log". In short:
- **Frame:** clean, full-bleed 9:16 like a normal Instagram Reel. No rounded film or card border, no REC timecode, no viewfinder corners, no progress bar.
- **Graphics to leave out:**
  - no heartbeat/ECG line graphic;
  - no arrow on the CTA;
  - no underline under the title;
  - no logo (end with a clean navy slot so the client can add the logo themselves).
- **Hook:** use the slam-in title with the brief font flicker. The client rejected a "biomarker scan" reticle/DNA/HUD title.
- **Numbers:** must never sit behind text. Move them with `num_y`, e.g. under the callout brackets.
- **Copy:** proper grammar and punctuation. Highlight boxes exclude trailing punctuation, and lines are balanced so no word sits alone on the last line.
- **Data:** never invent values. Callout tags name the test shown (e.g. "FORCE PLATE") and carry no numbers.
- **Changes:** when the user asks for a specific change, change only that.
