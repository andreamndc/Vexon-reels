---
name: vexon-reel-editor
description: Edit raw clips into a branded 9:16 Instagram/TikTok reel for VEXON (Vexon Med) in the editing style of a reference reel - analyse the reference, storyboard first, then render beat-synced kinetic typography, motion-graphic callouts and transitions with ffmpeg + Python. Use when the user uploads raw footage plus a brief (on-screen lines, CTA) and/or a reference TikTok/Reel link and asks for a reel, short, or social video edit, or asks to revise one made this way.
---

# VEXON reel editor

Turns raw phone clips + a brief + a reference reel into a finished vertical reel in the approved VEXON
house style. Everything is rendered by `scripts/render_reel.py` from a **plan JSON**, so every revision is
a small plan edit plus a re-render.

The approved reference build is `examples/longevity_assessment.plan.json`, the "Why get a longevity
assessment?" reel (v6). Start new reels by copying it.

## Requirements
`ffmpeg`/`ffprobe`, Python 3 with `numpy` + `Pillow`, and `yt-dlp` for downloading references (the script
installs it if missing). The brand fonts Oswald and Public Sans are bundled in `assets/fonts/` (both OFL).

## Workflow

### 1. Gather inputs
- **Raw clips:** any orientation; `.MOV` rotation metadata is handled automatically.
- **Brief:** the hook question, the lines that appear one at a time, and the CTA.
- **Brand sheet:** the defaults are in `references/style-guide.md`. Only override them if the user gives new ones.
- **Reference reel URL (optional):** its editing techniques are copied, never its content or its audio.
- **Song:** see the "Music" section below.

### 2. Analyse the reference (if one is given)
```bash
scripts/analyze_reference.sh "<url>" <work>/ref
```
1. Read `sheet*.jpg`, `open.jpg` and the strips in `cuts/`.
2. Write down the techniques: cut rhythm, transitions, title treatment, framing, grade and montage pacing.
3. Map each technique to the renderer's vocabulary (see `references/style-guide.md`, "Technique catalogue").
4. Tell the user, in plain language, which techniques you found.

### 3. Inspect the raw clips
```bash
scripts/inspect_clips.sh <work>/clips clip1 clip2 ...
scripts/grid_frame.sh <clip> <sec> <out.png> [cx] [cy] [rot]
```
`inspect_clips.sh` makes timecoded contact sheets. `grid_frame.sh` shows the output framing with a pixel
grid, so you can read off callout boxes, ring centres and text positions.

Watch for:
- **Mid-clip rotation:** the phone turned sideways part-way through. Set `"rot": true` and only use that time range.
- **Shot changes inside a clip:** the first frame must be the intended shot. Nudge `ss` if it isn't (the v6 hook needed 4.9 → 5.25).
- **Short sections:** a shot's source length is `dur × speed`; keep it inside a single continuous section of the clip.

### 4. Write the plan, then STORYBOARD FIRST
1. Copy the example plan.
2. Set `sources`, `bpm` and the shots, then fill in the brief text verbatim, with corrected grammar and punctuation.
3. Render the storyboard:
   ```bash
   python3 scripts/storyboard.py plan.json <work>/storyboard.png
   ```
4. Send the storyboard to the user before doing the full render. The user explicitly asks for a storyboard first.

### 5. Render, check, deliver
```bash
python3 scripts/render_reel.py plan.json <work>/render.mp4          # ~5 min for 30 s; run in background
python3 scripts/render_reel.py plan.json <work>/s --stills 2.0,12.0  # fast spot checks
scripts/finalize.sh <work>/render.mp4 /path/Deliverable.mp4 [licensed_audio] [offset]
```
- Before re-rendering, check changed sections with `--stills`.
- After rendering, sample frames from the output (e.g. a ffmpeg `select=...,tile` contact strip) and look at them before you send anything.
- Deliver with a short note: what changed, what's left, and anything the user must do (add music, add logo).

## Talking-head reels (presenter + B-roll)
Used when the client sends a presenter clip ("green-screen talking head") to lead the reel.
1. **Matte**: `scripts/matte.py <clip> <work>/matte <rvm_mobilenetv3_fp32.onnx>` makes `alpha.mp4` and `fgr.mp4`
   with Robust Video Matting. It works on a real green screen *and* on a plain wall, keeps hair detail and
   removes background spill. Get the model from the RVM GitHub release (Hugging Face may be blocked). Takes ~1.3 frames/s on CPU.
2. **Transcribe**: use sherpa-onnx with `sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8` (from the sherpa-onnx GitHub
   `asr-models` release) to get word timestamps. Then hand-chunk the captions into natural phrases of 2–6 words,
   and proofread them: fix model slips and add any missing commas.
3. **Plan**: write `talk.plan.json` (see `examples/mobility_talk.plan.json`).
   - `talk` segments put the presenter over a soft-focus, dimmed B-roll with a navy floor and a drop shadow.
   - `broll` segments are full-screen cutaways while she keeps talking; give the questions `num` 01/02/03.
   - `pip` segments show sharp, full-screen B-roll with the presenter smaller in the bottom-left corner:
     `"place": {"scale": 0.58, "x": 300}`. The left side keeps clear of Instagram's buttons. Change the B-roll per phrase.
   - Use `"tin": "morph"` on the next `talk` segment so she glides back to full size while the background softens.
   - Cut in her pauses. Transitions: `xfade` back to the presenter, `cutout`/`whip` into cutaways. No flashes.
   - Captions: Oswald uppercase, cream, an orange box on 1–2 key words per phrase, at `caption_y` 520,
     above her head and inside the safe zone. Use `style: slam` for the hook phrases and `style: numbers`
     for a spoken-number payoff ("10, 20, 30 YEARS FROM NOW.").
4. **Render**: `scripts/render_talk.py talk.plan.json out.mp4` (~10 min for 45 s; use `--stills` first).
   The voice is cleaned and set to -14 LUFS. The end is a blur-dissolve into an empty navy logo slot.
5. **Music**: there are still no ripped songs. Tell the client to add the track in Instagram with the music at
   ~10–15% and the original audio at 100%. `scripts/mix_music.sh` ducks a *licensed* file under the voice.

Talking-head feedback:
- Presenter is the main focus, and text never covers her face or body.
- Most text is removed; captions carry the message, with only a few key text moments.
- The logo transition must be gradual, never a hard cut.
- For the closing (brand line + CTA), show sharp B-roll with the presenter small in the corner (`pip`), not only blurred backgrounds. She glides there with `morph`.

## Plan format (one entry per shot, played in order)

| key | meaning |
|---|---|
| `src` / `ss` | Source key from `sources` (or `null` for a solid end slot) and its start time in seconds. |
| `bars` or `beats` | Shot length on the beat grid. One bar is 4 beats; at 140 BPM a bar is 1.714 s. |
| `kind` | `title`, `line` (the default when `text` is set), `cta`, `burst` (fast montage), `plain`, or `end`. |
| `tin` | Transition into this shot: `cut`, `flash`, `cutout`, `whip`, `panels`, `punch`, or `hit` (montage). |
| `z` | Zoom at the start and end of the shot, e.g. `[1.0, 1.1]` for a push-in. A beat pulse is added automatically. |
| `cx`, `cy` | Crop anchor (0–1) when the source is wider or taller than 9:16. |
| `speed` | Playback speed. Below 1 is slow-mo. |
| `bright` | Grade brightness offset. |
| `rot` | Rotate sideways footage back to upright. |
| `text`, `highlight` | The on-screen line and the key words that get the orange box. |
| `ty`, `size` | Text centre y position and font size. Defaults are 1130 and an automatic size. |
| `num`, `num_y` | Giant outlined number behind the line (e.g. `"03"`) and its y position. Keep it clear of the text. |
| `text_span: 2` + `cont: true` on the next shot | Hold one line of text across two shots. |
| `fx` | Callout: `{"kind":"brackets"\|"scan","box":[x0,y0,x1,y1],"tag":"..."}` or `{"kind":"rings","c":[x,y],"tag":"..."}`. |
| `title_words` | For the hook: a list of `{text, beat, size, y, color}`. Add `"box": true` to one word for an orange emphasis box that wipes in after it lands (used for a closing "payoff" line). |
| `band_y` | Centre of the dark legibility band on a `title` shot (default 820). |
| `"tin":"fade"` + `fade_beats` | On the `end` shot: the previous shot dissolves into the fill colour over its last N beats (default 1). Use for "fade into a clean background". |
| `note` | Caption shown on the storyboard. |

Top-level keys:
- `bpm`, `fps`, `size`.
- `look`, with the flags `grade`, `grain`, `beat_pulse` and `card_border`. **Leave `card_border` false.**
- `brand_colors`, used only to override the defaults.
- `title`, `music_note` (both shown on the storyboard).

## Music
Never download, rip or embed copyrighted songs, including ones the user names, such as "Band4Band".
Instead:
1. Cut the edit to the song's tempo by setting `bpm`. Each shot is a whole number of bars and the montage uses 8th notes.
2. Export without sound (silent audio track) using `finalize.sh`.
3. Tell the user to add the sound in the app, starting it on a downbeat.

If the user names a song only by a TikTok/Reel link, download that reference **only to analyse it** (identify the track, BPM and beat phase, e.g. with `librosa.beat.beat_track`; fit a line to the beats for exact BPM). Set reel t=0 on a strong hit and land slams/cuts on the song's accents (pickups count). The audio is never muxed into the deliverable. Mention that business accounts are often limited to the Commercial Music Library.

If the user supplies an audio file they have rights to, pass it to `finalize.sh` with an offset.

## House rules (learned from client feedback, do not regress)
See `references/style-guide.md` → "Client feedback log". In short:
- **Frame:** clean, full-bleed 9:16 like a normal Instagram Reel. No rounded film or card border, no REC timecode, no viewfinder corners, no progress bar.
- **Graphics to leave out:**
  - no heartbeat/ECG line graphic;
  - no arrow on the CTA;
  - no underline under the title;
  - no logo (end with a clean navy slot so the client can add the logo themselves).
- **Hook:** use the slam-in title with the brief font flicker. The client rejected a "biomarker scan" reticle/DNA/HUD title.
- **Numbers:** must never sit behind text. Move them with `num_y`, e.g. under the callout brackets.
- **Copy:** proper grammar and punctuation. Highlight boxes exclude trailing punctuation, and lines are balanced so no word sits alone on the last line.
- **Data:** never invent values. Callout tags name the test shown (e.g. "FORCE PLATE") and carry no numbers.
- **Changes:** when the user asks for a specific change, change only that.
