---
name: vexon-reel-editor
description: Edit raw clips into a branded 9:16 Instagram/TikTok reel for VEXON (Vexon Med) in the editing style of a reference reel - analyse the reference, storyboard first, then render beat-synced kinetic typography, motion-graphic callouts and transitions with ffmpeg + Python. Use when the user uploads raw footage plus a brief (on-screen lines, CTA) and/or a reference TikTok/Reel link and asks for a reel, short, or social video edit, or asks to revise one made this way.
---

# VEXON reel editor

Turns raw phone clips + a brief + a reference reel into a finished vertical reel in the approved VEXON
house style. Everything is rendered by `scripts/render_reel.py` from a **plan JSON**, so every revision is
a small plan edit plus a re-render.

The approved reference build is `examples/longevity_assessment.plan.json`. For a calmer, editorial brief ("no trendy edits") start from `examples/dead_hang.plan.json`, which uses only soft transitions and a persistent header. The original reference build is `examples/longevity_assessment.plan.json`, the "Why get a longevity
assessment?" reel (v6). Start new reels by copying it.

## Requirements
`ffmpeg`/`ffprobe`, Python 3 with `numpy` + `Pillow`, and `yt-dlp` for downloading references (the script
installs it if missing). The brand fonts Oswald and Public Sans are bundled in `assets/fonts/` (both OFL).

## Workflow

### 1. Gather inputs
- **Raw clips:** any orientation; `.MOV` rotation metadata is handled automatically.
- **Brief:** the hook question, the lines that appear one at a time, and the CTA.
- **Brand sheet:** the defaults are in `references/style-guide.md`. Only override them if the user gives new ones.
- **Reference reel URL (optional):** its editing techniques are copied, never its content or its audio.
- **Song:** see the "Music" section below.

### 2. Analyse the reference (if one is given)
```bash
scripts/analyze_reference.sh "<url>" <work>/ref
```
1. Read `sheet*.jpg`, `open.jpg` and the strips in `cuts/`.
2. Write down the techniques: cut rhythm, transitions, title treatment, framing, grade and montage pacing.
3. Map each technique to the renderer's vocabulary (see `references/style-guide.md`, "Technique catalogue").
4. Tell the user, in plain language, which techniques you found.

### 3. Inspect the raw clips
```bash
scripts/inspect_clips.sh <work>/clips clip1 clip2 ...
scripts/grid_frame.sh <clip> <sec> <out.png> [cx] [cy] [rot]
```
`inspect_clips.sh` makes timecoded contact sheets. `grid_frame.sh` shows the output framing with a pixel
grid, so you can read off callout boxes, ring centres and text positions.

Watch for:
- **Mid-clip rotation:** the phone turned sideways part-way through. Set `"rot": true` and only use that time range.
- **Shot changes inside a clip:** the first frame must be the intended shot. Nudge `ss` if it isn't (the v6 hook needed 4.9 → 5.25).
- **Short sections:** a shot's source length is `dur × speed`; keep it inside a single continuous section of the clip.

### 4. Write the plan, then STORYBOARD FIRST
1. Copy the example plan.
2. Set `sources`, `bpm` and the shots, then fill in the brief text verbatim, with corrected grammar and punctuation.
3. Render the storyboard:
   ```bash
   python3 scripts/storyboard.py plan.json <work>/storyboard.png
   ```
4. Send the storyboard to the user before doing the full render. The user explicitly asks for a storyboard first.

### 5. Render, check, deliver
```bash
python3 scripts/render_reel.py plan.json <work>/render.mp4          # ~5 min for 30 s; run in background
python3 scripts/render_reel.py plan.json <work>/s --stills 2.0,12.0  # fast spot checks
scripts/finalize.sh <work>/render.mp4 /path/Deliverable.mp4 [licensed_audio] [offset]
```
- Before re-rendering, check changed sections with `--stills`.
- After rendering, sample frames from the output (e.g. a ffmpeg `select=...,tile` contact strip) and look at them before you send anything.
- Deliver with a short note: what changed, what's left, and anything the user must do (add music, add logo).

## Plan format (one entry per shot, played in order)

| key | meaning |
|---|---|
| `src` / `ss` | Source key from `sources` (or `null` for a solid end slot) and its start time in seconds. |
| `bars` or `beats` | Shot length on the beat grid. One bar is 4 beats; at 140 BPM a bar is 1.714 s. |
| `kind` | `title`, `line` (the default when `text` is set), `cta`, `burst` (fast montage), `plain`, or `end`. |
| `tin` | Transition into this shot: `cut`, `flash`, `cutout`, `whip`, `panels`, `punch`, or `hit` (montage). Editorial (no shake/RGB split): `dissolve`, `slide` (vertical push), `wipe` (soft diagonal, orange edge), `dip` (through navy). `tdur` sets their length in frames. Text on the outgoing shot holds and rides a soft transition. |
| `zc` | Zoom centre `[x, y]` in output px (default frame centre), e.g. to push toward the grip. |
| `ttop`, `reveal`, `stagger`, `box_beats`, `text_delay`, `maxw`, `lh_k` | Text: top-anchor y, line reveal secs, per-line stagger, beats until the orange box, delay, max width, line height. |
| `band_y`, `band_h`, `band_s` / `band` | Legibility band position/height/strength for a line; `band: [y,h,s]` on a textless shot. |
| `header_intro`, `header` | With top-level `header`: the label (e.g. "IT'S:") reveals big on the `header_intro` shot, glides up into a small header on the first `header` shot and stays fixed through transitions until the last one. |
| `z` | Zoom at the start and end of the shot, e.g. `[1.0, 1.1]` for a push-in. A beat pulse is added automatically. |
| `cx`, `cy` | Crop anchor (0–1) when the source is wider or taller than 9:16. |
| `speed` | Playback speed. Below 1 is slow-mo. |
| `bright` | Grade brightness offset. |
| `rot` | Rotate sideways footage back to upright. |
| `text`, `highlight` | The on-screen line and the key words that get the orange box. |
| `ty`, `size` | Text centre y position and font size. Defaults are 1130 and an automatic size. |
| `num`, `num_y` | Giant outlined number behind the line (e.g. `"03"`) and its y position. Keep it clear of the text. |
| `text_span: 2` + `cont: true` on the next shot | Hold one line of text across two shots. |
| `fx` | Callout: `{"kind":"brackets"\|"scan","box":[x0,y0,x1,y1],"tag":"..."}` or `{"kind":"rings","c":[x,y],"tag":"..."}`. |
| `title_words` | For the hook: a list of `{text, beat, size, y, color}`. |
| `note` | Caption shown on the storyboard. |
| `secs` | Shot length in seconds instead of bars/beats (voiceover-led edits: cut on phrase starts). |
| `pop` | Centred line settles from (1+pop)× scale, e.g. 0.08: emphasis for questions without flash. |

Top-level keys:
- `bpm`, `fps`, `size`.
- `captions`: `{file, size, y, maxw}` closed captions from a JSON list of `{text, words:[{w,s,e}]}` (house style: Public Sans Bold, ALL CAPS — `font: "sub_bold", upper: true`, 46 px; cream, spoken word orange, fixed at y≈1160 above the IG caption area). See `examples/grip_strength_vo.plan.json`.
- `header`: `{text, big_size, big_y, big_color, size, y, color, delay}` for the persistent section label.
- `look.pulse`: beat-pulse zoom amount (default 0.022; 0.01 for calmer, editorial reels).
- `look`, with the flags `grade`, `grain`, `beat_pulse` and `card_border`. **Leave `card_border` false.**
- `brand_colors`, used only to override the defaults.
- `title`, `music_note` (both shown on the storyboard).

## Music
Never download, rip or embed copyrighted songs, including ones the user names, such as "Band4Band".
Instead:
1. Cut the edit to the song's tempo by setting `bpm`. Each shot is a whole number of bars and the montage uses 8th notes.
2. Export without sound (silent audio track) using `finalize.sh`.
3. Tell the user to add the sound in the app, starting it on a downbeat. Mention that business accounts are often limited to the Commercial Music Library.

If the user supplies an audio file they have rights to, pass it to `finalize.sh` with an offset.

## House rules (learned from client feedback, do not regress)
See `references/style-guide.md` → "Client feedback log". In short:
- **Frame:** clean, full-bleed 9:16 like a normal Instagram Reel. No rounded film or card border, no REC timecode, no viewfinder corners, no progress bar.
- **Graphics to leave out:**
  - no heartbeat/ECG line graphic;
  - no arrow on the CTA;
  - no underline under the title;
  - no logo (end with a clean navy slot so the client can add the logo themselves).
- **Hook:** use the slam-in title with the brief font flicker. The client rejected a "biomarker scan" reticle/DNA/HUD title.
- **Numbers:** must never sit behind text. Move them with `num_y`, e.g. under the callout brackets.
- **Copy:** proper grammar and punctuation. Highlight boxes exclude trailing punctuation, and lines are balanced so no word sits alone on the last line.
- **Data:** never invent values. Callout tags name the test shown (e.g. "FORCE PLATE") and carry no numbers.
- **Changes:** when the user asks for a specific change, change only that.

## Voiceover reels
1. Transcribe with word timestamps. If HuggingFace is blocked, sherpa-onnx (pip) + the Parakeet TDT int8 model from the k2-fsa/sherpa-onnx GitHub release `asr-models` works offline.
2. If questions need reading time, splice ~0.45 s of the VO's own room tone after each one (never digital silence) and shift the word times.
3. Cut shots (`secs`) on phrase starts ~0.1 s before the word; big centred text only where the on-screen line is the point (hook, questions, final line). Mark those caption chunks `"hide": true` so the burned-in captions never double the big text (the SRT keeps every line).
   Client prefers no added pauses (shorter reel) — only splice room tone if asked.
4. Master the VO: highpass 80 Hz, light EQ + 3:1 compression, loudnorm to -14 LUFS / -1.5 dBTP; mux it padded to the video length. Music stays the client's in-app track at low volume unless they supply a licensed file.
