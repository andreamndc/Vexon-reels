# VEXON reel style guide

## Brand
- **Colours:**
  - `#ff7a1a` orange: key-word highlight boxes, callouts, scan lines, rings, tags.
  - `#fbf7ef` cream: all body text, numbers, bracket corners.
  - `#0b1525` navy: text inside the orange boxes and the end slot.
  - `#f7b137` gold: an available accent.
  - `#ffffff` white.
  - Wider palette: `#b8954a #7f2b0a #8a8578 #d9d2c4 #040101 #223450 #4a5568 #b6c2d6`.
- **Fonts:**
  - Titles: **Oswald** (weight 650 for text, 700 for the giant numbers).
  - Subtitles and tags: **Public Sans**.
  - Subheadings: Times New Roman MT. It is not bundled. Liberation Serif stands in for it, and only inside the title's font flicker.
- **Logo:** the client adds it manually in the end slot. Don't burn it in.
- **Tone:** premium, modern, clean, doctor-backed. Avoid playful or gimmicky effects.

## Look (fixed defaults)
- **Grade:** contrast 1.10, saturation 0.88, teal shadows and warm highlights, light vignette, fine grain.
- **Text background:** a soft dark band behind the text for legibility, plus a soft drop shadow on all graphics.
- **Frame:** full-bleed 9:16, no border.
- **Safe zones:** keep text between y ≈ 400 and 1450. The top ~250 px and the bottom ~400 px are covered by the app UI.

## Technique catalogue (renderer vocabulary)
| technique | how to request it | use for |
|---|---|---|
| White flash | `"tin":"flash"` | Section starts and after the montage. |
| Jagged paper-cutout reveal | `"tin":"cutout"` | A tactile change of scene. |
| Whip pan with motion blur | `"tin":"whip"` | Two related shots, e.g. angle A → B. |
| Panel drop (4 strips) | `"tin":"panels"` | Building energy before the drop. |
| Zoom punch | `"tin":"punch"` | Into the CTA. |
| Shake + RGB split | Automatic on every transition | Impact. |
| 8th-note montage | A run of `"kind":"burst","beats":0.5` shots | The music drop (8 cuts). |
| Beat pulse zoom | Automatic, every 2 beats | Keeping still shots alive. |
| Slam title + font flicker | `"kind":"title"` + `title_words` | The hook (first 2 bars). |
| Kinetic line + orange box | `"text"` + `"highlight"` | Every brief line. |
| Giant outlined number | `"num"` (+ `"num_y"`) | Numbering the brief lines. |
| Brackets + tag | `fx.kind = "brackets"` | Pointing at a device or test. |
| Scan line in brackets | `fx.kind = "scan"` | Data screens. |
| Sonar rings + leader tag | `fx.kind = "rings"` | A person or vital sign. |

## Pacing template (140 BPM, ~32 s)
| section | length |
|---|---|
| Hook | 2 bars |
| Each brief line | 2 bars |
| Montage | 1 bar of 8 cuts |
| Long line | 3 bars, split across 2 shots |
| CTA | 2 bars |
| Clean end slot | 1 bar |

## Client feedback log (newest last)
1. v1 → v2:
   - Remove the heartbeat graphic and the logo.
   - Use Band4Band, so cut to its tempo and export silent.
   - Add engaging motion graphics.
   - Storyboard first.
2. v2 → v3:
   - Fix grammar and punctuation.
   - Remove the REC timecode, viewfinder corners and progress bar.
3. v3 → v4: the client asked for a richer title animation. The "biomarker scan" version was built (reticle, DNA helix, biomarker chips).
4. v4 → v5:
   - Remove the CTA arrow.
   - Move "03" so it doesn't sit behind the text, then under the viewfinder brackets.
5. v5 → v6:
   - **The biomarker-scan title was rejected.** Go back to the slam/flicker title, with the underline removed.
   - Remove the film/card border; it should look like a standard full-screen Instagram Reel.

6. Mobility and Longevity reel (new topic, same series):
   - The music was "Loser" by Tame Impala, taken from a TikTok link. The cut follows its ~83 BPM grid, and the export is silent.
   - The ending is a fade into a clean navy slot, not a flash.
   - The final line is the visual highlight, using the slam title plus an orange box on the payoff word.

## Gotchas
- **Background renders:** when killing a background render, match only the render process, e.g. `ps aux | grep "[r]ender_reel.py out"`. Don't use `pkill -f` with a pattern that also matches your own shell.
- **ffmpeg in loops:** ffmpeg inside a `while read` loop needs `-nostdin`.
- **Glyph support:** Public Sans has no subscript ₂, so write "VO2".
- **Long renders:** a full render takes ~5 min. Run it in the background and spot-check with `--stills` before re-rendering.
