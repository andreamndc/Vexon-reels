#!/usr/bin/env bash
# Probe raw clips (duration, size, rotation) and make timecoded contact sheets (~24 frames each).
# Usage: inspect_clips.sh <outdir> clip1 [clip2 ...]
# Watch for: clips where the phone rotated mid-recording (content turns sideways) -> use "rot": true
# for that time range; and shot changes inside a clip (pick ss so the first frame is the right shot).
set -euo pipefail
OUT="$1"; shift; mkdir -p "$OUT"; i=0
for f in "$@"; do i=$((i+1))
  echo "== [$i] $f"
  ffprobe -v error -show_entries format=duration:stream=codec_type,width,height,r_frame_rate:stream_side_data=rotation -of compact "$f" | grep -E "video|format|rotation"
  d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$f")
  r=$(python3 -c "print(max(0.5,$d/24))")
  ffmpeg -v error -y -i "$f" -vf "fps=1/$r,scale=150:-1,drawtext=text='%{pts\:hms}':x=4:y=4:fontsize=14:fontcolor=yellow:box=1:boxcolor=black,tile=8x3" -frames:v 1 "$OUT/clip$i.jpg"
done
ls "$OUT"
