#!/usr/bin/env python3
"""Tighten a talking-head take: keep the given [start, end] intervals (seconds), drop the rest.
Video: 4-frame dissolve at each cut so the jump is soft. Audio: 8 ms fade at each side of a cut (no clicks).
NO denoise / compression / EQ: the voice is left exactly as recorded.
Usage: cut_pauses.py <clip> <keep.json> <out.mp4>"""
import json, subprocess, sys
import numpy as np
clip, keep, out = sys.argv[1], json.load(open(sys.argv[2])), sys.argv[3]
pr = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'json', clip]))['streams'][0]
W, H, FPS, SR, XF = pr['width'], pr['height'], 30, 48000, 4
iv = [(int(round(a * FPS)), int(round(b * FPS))) for a, b in keep]
# ---- audio
raw = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', clip, '-vn', '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-'])
au = np.frombuffer(raw, np.float32).reshape(-1, 2); parts = []; fd = int(0.008 * SR); ramp = np.linspace(0, 1, fd, dtype=np.float32)[:, None]
for k, (f0, f1) in enumerate(iv):
    seg = au[int(f0 / FPS * SR):int(f1 / FPS * SR)].copy()
    if k > 0: seg[:fd] *= ramp
    if k < len(iv) - 1: seg[-fd:] *= ramp[::-1]
    parts.append(seg)
np.concatenate(parts).astype(np.float32).tofile(out + '.pcm')
# ---- video (sequential read; frames just after a kept interval are buffered for the dissolve)
rd = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', clip, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-r', str(FPS), '-'], stdout=subprocess.PIPE)
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                        '-f', 'f32le', '-ar', str(SR), '-ac', '2', '-i', out + '.pcm', '-c:v', 'libx264', '-crf', '12', '-preset', 'medium',
                        '-pix_fmt', 'yuv420p', '-c:a', 'pcm_s16le', '-shortest', out], stdin=subprocess.PIPE)
tail = []; k = 0; j = 0; n = 0; nout = 0
while True:
    b = rd.stdout.read(W * H * 3)
    if len(b) < W * H * 3: break
    fr = np.frombuffer(b, np.uint8)
    while k < len(iv) and n >= iv[k][1]: k += 1; j = 0
    if k < len(iv) and iv[k][0] <= n < iv[k][1]:
        p = n - iv[k][0]
        if k > 0 and p < XF and p < len(tail):
            r = (p + 1) / (XF + 1); fr = (tail[p].astype(np.float32) * (1 - r) + fr * r).astype(np.uint8)
        if p == XF: tail = []
        enc.stdin.write(fr.tobytes()); nout += 1
    elif k > 0 and k <= len(iv) and n >= iv[k - 1][1] and len(tail) < XF and (k == len(iv) or n < iv[k][0]):
        tail.append(fr)
    n += 1
enc.stdin.close(); enc.wait(); print('frames', nout, 'seconds', nout / FPS)
import os; os.remove(out + '.pcm')
