# Keep only the largest connected region of each matte frame (drops chair/door fragments) and log head-top y.
# Usage: clean_matte.py <matte_dir>
import numpy as np, os
from PIL import Image
from scipy import ndimage
import sys
D = sys.argv[1] if len(sys.argv) > 1 else 'matte'
tops=[]; removed=0
for f in sorted(os.listdir(D)):
    im = np.array(Image.open(D+'/'+f))
    a = im[...,3].astype(np.float32)
    lab, n = ndimage.label(ndimage.binary_dilation(a>25, iterations=3))
    if n > 1:
        sizes = ndimage.sum(np.ones_like(a), lab, range(1, n+1))
        keep = lab == (np.argmax(sizes)+1)
        keep = ndimage.gaussian_filter(keep.astype(np.float32), 2)
        removed += (a*(1-np.clip(keep*1.5,0,1)) > 40).sum() > 0
        a = a*np.clip(keep*1.5,0,1)
    im[...,3] = a.astype(np.uint8)
    Image.fromarray(im).save(D+'/'+f, compress_level=1)
    rows = np.where((a>128).sum(1) > 20)[0]
    tops.append(rows[0] if len(rows) else 1280)
tops=np.array(tops)
print('frames with fragments removed:', removed)
for s in range(0, len(tops), 30): print(f'{s/30:4.1f}s head_top_src={tops[s:s+30].min()} -> out {tops[s:s+30].min()*1.5:.0f}')
