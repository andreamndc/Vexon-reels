#!/usr/bin/env python3
"""Render a VEXON talking-head reel: a matted presenter (see matte.py) composited over B-roll, with
full-screen B-roll cutaways, synced brand captions, key-moment text treatments and a soft end transition
into a clean logo slot. Audio = the presenter's own voice (cleaned + loudness-normalised).

Usage:
  render_talk.py talk.plan.json out.mp4
  render_talk.py talk.plan.json stills_prefix --stills 1.0,12.5

Plan keys (see examples/mobility_talk.plan.json):
  size, fps, look{grade,grain}, sources{KEY: path}
  talent{src, alpha, fgr, scale, dy, end}      matte from matte.py; `end` = when the talk section stops
  segments[{t0, mode: talk|pip|broll, src, ss, speed, z, tin: cut|xfade|cutout|whip|morph, num, num_y, blur, dim,
            place{scale, x, dy} (pip: presenter small in a corner over sharp B-roll)}]
  captions[{t0, t1, text, highlight[], style: ''|slam|numbers, words[[t, word]]}]   (from the transcript)
  caption_y, caption_size
  end{transition, hold, fill}                  blur-dissolve into an empty brand slot (logo added later)
"""
import json, math, os, random, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__)); SKILL = os.path.dirname(HERE)
plan_path, OUT = sys.argv[1], sys.argv[2]
STILLS = [float(x) for x in sys.argv[sys.argv.index('--stills') + 1].split(',')] if '--stills' in sys.argv else None
P = json.load(open(plan_path)); PLAN_DIR = os.path.dirname(os.path.abspath(plan_path))
W, H = P.get('size', [1080, 1920]); FPS = P.get('fps', 30)
LOOK = {'grade': True, 'grain': True}; LOOK.update(P.get('look', {}))

def hex2rgb(h): h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
BR = {'orange': '#ff7a1a', 'gold': '#f7b137', 'cream': '#fbf7ef', 'navy': '#0b1525', 'white': '#ffffff'}
BR.update(P.get('brand_colors', {})); COL = {k: hex2rgb(v) for k, v in BR.items()}
ORANGE, CREAM, NAVYD = COL['orange'], COL['cream'], COL['navy']
def color(n): return COL[n] if n in COL else hex2rgb(n)
FONT_DIR = P.get('fonts_dir') or os.path.join(SKILL, 'assets', 'fonts')
SERIF = '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf'
_fc = {}
def font(kind, size):
    k = (kind, size)
    if k not in _fc:
        path, wt = {'title': ('Oswald.ttf', 650), 'title_bold': ('Oswald.ttf', 700), 'sub': ('PublicSans.ttf', 800),
                    'sub_light': ('PublicSans.ttf', 300), 'serif': (None, None)}[kind]
        f = ImageFont.truetype(os.path.join(FONT_DIR, path) if path else SERIF, size)
        if wt:
            try: f.set_variation_by_axes([wt])
            except Exception: pass
        _fc[k] = f
    return _fc[k]
def src_path(key):
    p = P['sources'].get(key, key); return p if os.path.isabs(p) else os.path.join(PLAN_DIR, p)

def clamp(x): return min(max(x, 0.0), 1.0)
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def easeio(x): x = clamp(x); return x * x * (3 - 2 * x)

GRADE = ("eq=contrast=1.10:brightness={b}:saturation=0.88,"
         "colorbalance=rs=-0.04:bs=0.06:rm=0.03:bm=-0.02:rh=0.08:gh=0.02:bh=-0.07,vignette=angle=PI/4.5")

class Stream:
    """Sequential raw-frame reader from ffmpeg (seeks on demand)."""
    def __init__(self, path, vf, ss=0.0, speed=1.0, pix='rgb24', ch=3):
        self.path, self.vf, self.ss, self.speed, self.pix, self.ch = path, vf, ss, speed, pix, ch
        self.p = None; self.n = 0; self.last = None
    def _start(self, i):
        self.p = subprocess.Popen(['ffmpeg', '-v', 'quiet', '-ss', f'{self.ss + i / FPS * self.speed:.4f}', '-i', self.path, '-an',
                                   '-vf', f"setpts=(PTS-STARTPTS)/{self.speed},fps={FPS}," + self.vf,
                                   '-f', 'rawvideo', '-pix_fmt', self.pix, '-'], stdout=subprocess.PIPE)
        self.n = i; self.last = None
    def frame(self, i):
        i = max(0, i)
        if self.p is None or i < self.n - (1 if self.last is not None else 0) or i > self.n + 90: self._start(i)
        sz = W * H * self.ch
        while self.n <= i:
            b = self.p.stdout.read(sz)
            if len(b) < sz: break
            self.last = np.frombuffer(b, np.uint8).reshape(H, W, self.ch); self.n += 1
        if self.last is None: self.last = np.zeros((H, W, self.ch), np.uint8)
        return self.last

FIT = f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H}"

# ---------------------------------------------------------------- talent (matted presenter)
T = P['talent']; TEND = T['end']
fgr_s = Stream(src_path(T['fgr']), f"scale={W}:{H}")
alp_s = Stream(src_path(T['alpha']), f"scale={W}:{H}", pix='gray', ch=1)
TGRADE = T.get('grade', [1.04, 0.0, 0.97])   # contrast, brightness, saturation (kept natural)
EDGE = np.ones(W, np.float32); _e = np.linspace(0, 1, 70, dtype=np.float32) ** 0.8; EDGE[:70] = _e; EDGE[-70:] = _e[::-1]

def talent_raw(t):
    i = int(round(min(t, T.get('last', 999)) * FPS))
    f = fgr_s.frame(i).astype(np.float32); a = alp_s.frame(i).astype(np.float32) / 255
    c, b, sat = TGRADE
    f = (f - 128) * c + 128 + 255 * b; g = f.mean(2, keepdims=True); f = g + (f - g) * sat
    return np.clip(f, 0, 255), a

def place(seg):
    """Presenter placement (scale, centre x, bottom y). talk = full size; pip = smaller, in a corner."""
    if seg['mode'] == 'pip':
        pl = seg.get('place', {}); return (pl.get('scale', 0.58), pl.get('x', 300), H + pl.get('dy', 0))
    return (T.get('scale', 1.0), W / 2, H + T.get('dy', 0))

def talent_layers(t, pl):
    f, a = talent_raw(t); sc, xc, bottom = pl
    if sc < 0.97: a = a * EDGE[None, :, None]          # soften where the source frame cuts the shoulders
    w, h = int(round(W * sc)), int(round(H * sc))
    if (w, h) != (W, H):
        f = np.asarray(Image.fromarray(f.astype(np.uint8)).resize((w, h), Image.LANCZOS), np.float32)
        a = np.asarray(Image.fromarray((a[..., 0] * 255).astype(np.uint8)).resize((w, h), Image.LANCZOS), np.float32)[..., None] / 255
    F = np.zeros((H, W, 3), np.float32); A = np.zeros((H, W, 1), np.float32)
    x0, y0 = int(round(xc - w / 2)), int(round(bottom - h))
    sx0, sy0 = max(0, -x0), max(0, -y0); dx0, dy0 = max(0, x0), max(0, y0)
    cw, ch = min(w - sx0, W - dx0), min(h - sy0, H - dy0)
    if cw > 0 and ch > 0:
        F[dy0:dy0 + ch, dx0:dx0 + cw] = f[sy0:sy0 + ch, sx0:sx0 + cw]; A[dy0:dy0 + ch, dx0:dx0 + cw] = a[sy0:sy0 + ch, sx0:sx0 + cw]
    return F, A

# ---------------------------------------------------------------- segments
SEG = P['segments']
for k, s in enumerate(SEG):
    s['t1'] = SEG[k + 1]['t0'] if k + 1 < len(SEG) else TEND + P['end']['transition']
    s.setdefault('tin', 'cut'); s.setdefault('speed', 1.0)
    vf = FIT
    if LOOK['grade']: vf += ',' + GRADE.format(b=s.get('bright', -0.02))
    s['_r'] = Stream(src_path(s['src']), vf, s['ss'], s['speed'])
def seg_at(t):
    for k, s in enumerate(SEG):
        if s['t0'] <= t < s['t1']: return k
    return len(SEG) - 1

def zoom(img, z):
    if abs(z - 1) < 1e-3: return img
    cw, ch = W / z, H / z; x0, y0 = (W - cw) / 2, (H - ch) / 2
    return np.asarray(Image.fromarray(img.astype(np.uint8)).resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + cw, y0 + ch)), np.float32)

def blur(arr, r):
    if r < 0.5: return arr
    im = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)).resize((W // 4, H // 4), Image.BILINEAR)
    return np.asarray(im.filter(ImageFilter.GaussianBlur(r / 4)).resize((W, H), Image.BICUBIC), np.float32)

def floor(bg, strength, power):
    g = np.linspace(0, 1, H, dtype=np.float32)[:, None, None] ** power
    return bg * (1 - strength * g) + np.array(NAVYD, np.float32) * strength * g

def seg_bg(k, t):
    """Background plate of segment k at time t: soft-focus + dimmed for talk, sharp for pip/broll."""
    s = SEG[k]; lt = max(0.0, t - s['t0'])
    bg = s['_r'].frame(int(round(lt * FPS))).astype(np.float32)
    z0, z1 = s.get('z', [1.0, 1.06]); bg = zoom(bg, z0 + (z1 - z0) * easeio(lt / max(0.1, s['t1'] - s['t0'])))
    if s['mode'] == 'talk': return floor(blur(bg, s.get('blur', 14)) * s.get('dim', 0.6), 0.55, 2.2)
    if s['mode'] == 'pip': return floor(bg, 0.6, 4.0)        # B-roll stays sharp; a soft navy floor seats the presenter
    return bg

def seg_frame(k, t):
    """Composite of segment k at absolute time t (B-roll, plus the presenter on talk/pip segments).
    tin 'morph': the presenter glides between placements while the background crossfades (0.7 s)."""
    s = SEG[k]; lt = max(0.0, t - s['t0']); bg = seg_bg(k, t)
    if s['mode'] == 'broll': return bg
    pl = place(s)
    if s['tin'] == 'morph' and k > 0 and lt < 0.7:
        e = easeio(lt / 0.7); pp = place(SEG[k - 1]) if SEG[k - 1]['mode'] != 'broll' else pl
        pl = tuple(a + (b - a) * e for a, b in zip(pp, pl)); bg = seg_bg(k - 1, t) * (1 - e) + bg * e
    f, a = talent_layers(t, pl)
    sh = np.asarray(Image.fromarray((a[..., 0] * 255).astype(np.uint8)).resize((W // 4, H // 4)).filter(
        ImageFilter.GaussianBlur(9)).resize((W, H), Image.BILINEAR), np.float32)[..., None] / 255
    sh = np.roll(sh, (14, 10), (0, 1)); sh[:14] = 0; sh[:, :10] = 0   # offset shadow, no wrap-around
    bg = bg * (1 - 0.5 * sh)
    return f * a + bg * (1 - a)

# ---------------------------------------------------------------- transitions
JAG = {}
def jag_mask(step, nsteps, seed):
    key = (step, seed)
    if key in JAG: return JAG[key]
    rnd = random.Random(seed * 100 + step); level = H * (1.05 - 1.35 * ease((step + 1) / nsteps)); pts = []; n = 14
    for j in range(n + 1):
        x = W * j / n + (rnd.uniform(-30, 30) if 0 < j < n else 0)
        pts.append((x, level + rnd.uniform(-220, 220) + 160 * math.sin(j * 0.9 + seed)))
    edge = [(-10, pts[0][1])] + pts[1:-1] + [(W + 10, pts[-1][1])]
    m = Image.new('L', (W, H), 0); ImageDraw.Draw(m).polygon([(0, H + 50)] + edge + [(W + 10, H + 50)], fill=255)
    o = Image.new('L', (W, H), 0); ImageDraw.Draw(o).line(edge, fill=255, width=9, joint='curve')
    JAG[key] = (np.asarray(m, np.float32)[..., None] / 255, np.asarray(o, np.float32)[..., None] / 255)
    return JAG[key]
def hblur(a, amt):
    if amt < 2: return a
    out = np.zeros_like(a)
    for j in range(7): out += np.roll(a, int((j - 3) * amt / 7), axis=1)
    return out / 7
def shift(a, dx):
    dx = int(dx); out = np.zeros_like(a)
    if 0 <= dx < W: out[:, dx:] = a[:, :W - dx]
    elif -W < dx < 0: out[:, :W + dx] = a[:, -dx:]
    return out

def scene(t):
    k = seg_at(t); s = SEG[k]; fr = (t - s['t0']) * FPS; arr = seg_frame(k, t)
    if k == 0: return arr
    prev = lambda: seg_frame(k - 1, t)
    if s['tin'] == 'xfade' and fr < 8: r = easeio(fr / 8); arr = prev() * (1 - r) + arr * r
    elif s['tin'] == 'cutout' and fr < 10:
        m, o = jag_mask(int(fr) // 2, 5, k); arr = prev() * (1 - m) + arr * m; arr = arr * (1 - o) + 255 * o
    elif s['tin'] == 'whip' and fr < 7:
        r = ease(fr / 7); off = int(-r * W); b = 160 * (1 - r) + 20
        arr = shift(hblur(prev(), b), off) + shift(hblur(arr, b * (1 - r)), off + W)
    return arr

# ---------------------------------------------------------------- text
def layout(words, fnt, maxw):
    lines, cur = [], []; sp = fnt.getlength(' ')
    for w in words:
        test = cur + [w]
        if sum(fnt.getlength(x[0]) for x in test) + sp * (len(test) - 1) > maxw and cur: lines.append(cur); cur = [w]
        else: cur = test
    if cur: lines.append(cur)
    return lines

def caption(layer, c, lt, span, cy, size, maxw=860):
    """Brand caption: uppercase Oswald, lines wipe up (or SLAM in with font flicker for the hook), key words get
    the orange box (trailing punctuation outside), lines balanced so no word is left alone."""
    hl = [h.lower() for h in c.get('highlight', [])]
    words = [(w.upper(), any(h == w.lower().strip('.,?!…’\'') for h in hl)) for w in c['text'].split()]
    slam = c.get('style') == 'slam'
    fi = int(lt * FPS)
    kind = ['serif', 'sub_light', 'title', 'serif', 'sub'][(fi // 2) % 5] if slam and fi < 8 else 'title'
    fnt = font(kind, size if kind == 'title' else int(size * 0.85)); ftit = font('title', size)
    n0 = len(layout(words, ftit, maxw)); mw = maxw
    while mw > 300 and len(layout(words, ftit, mw - 10)) == n0: mw -= 10
    lines = layout(words, ftit, mw)
    lh = int(size * 1.14); y0 = cy - lh * len(lines) / 2; sp = fnt.getlength(' ')
    out = ease((lt - (span - 4 / FPS)) / (4 / FPS))
    sc = 1 + 0.5 * (1 - ease(lt / 0.16)) if slam else 1
    blk = Image.new('RGBA', (W, int(lh * len(lines) + size)), (0, 0, 0, 0))
    for li, line in enumerate(lines):
        r = 1 if slam else ease((lt - li * 0.06) / 0.28)
        if r <= 0: continue
        lw = sum(fnt.getlength(w) for w, _ in line) + sp * (len(line) - 1); x = (W - lw) / 2
        CH = int(size * 1.5); lc = Image.new('RGBA', (W, CH), (0, 0, 0, 0)); ld = ImageDraw.Draw(lc)
        bx = x
        for w, h in line:
            br = ease((lt - (0.22 if slam else 0.12)) / 0.22) if h and kind == 'title' else 0
            if br > 0:
                core = w.rstrip('.,?!…'); bw = fnt.getlength(core); bb = fnt.getbbox(core)
                ld.rectangle((bx - 10, 6 + bb[1] - 9, bx - 10 + (bw + 20) * br, 6 + bb[3] + 9), fill=ORANGE + (255,))
            ld.text((bx, 6), w, font=fnt, fill=CREAM + (255,))
            if br > 0:
                nv = Image.new('RGBA', lc.size, (0, 0, 0, 0)); ImageDraw.Draw(nv).text((bx, 6), w, font=fnt, fill=NAVYD + (255,))
                m = Image.new('L', lc.size, 0); ImageDraw.Draw(m).rectangle((bx - 10, 0, bx - 10 + (bw + 20) * br, CH), fill=255)
                lc.paste(nv, (0, 0), Image.composite(nv, Image.new('RGBA', lc.size, (0, 0, 0, 0)), m).getchannel('A'))
            bx += fnt.getlength(w) + sp
        off = (1 - r) * (lh + 8) - out * (lh + 8)
        sh = Image.new('RGBA', lc.size, (0, 0, 0, 0)); sh.paste(lc, (0, int(off)))
        cl = Image.new('L', lc.size, 0); ImageDraw.Draw(cl).rectangle((0, 0, W, 6 + ftit.getbbox('QJ,')[3] + 12), fill=255)  # wipe mask
        if not slam: sh.putalpha(Image.composite(sh.getchannel('A'), Image.new('L', lc.size, 0), cl))
        blk.alpha_composite(sh, (0, int(li * lh)))
    if slam and sc > 1.01:
        bw, bh = blk.size; blk = blk.resize((int(bw * sc), int(bh * sc)), Image.BICUBIC)
        blk = blk.crop(((blk.width - W) // 2, 0, (blk.width - W) // 2 + W, blk.height))
    if out > 0: blk.putalpha(blk.getchannel('A').point(lambda v: int(v * (1 - out))))
    layer.alpha_composite(blk, (0, int(y0 - 6 - (blk.height - (lh * len(lines) + size)) / 2 if slam else y0 - 6)))

def numbers_moment(layer, c, t, cy):
    """'10, 20, 30 YEARS FROM NOW.' - each number slams in on the word it is spoken, the payoff gets the orange box."""
    ws = c['words']; tail = ' '.join(w for _, w in ws[3:]).upper(); out = ease((t - (c['t1'] - 4 / FPS)) / (4 / FPS))
    nums = [(ws[i][0], ws[i][1].upper()) for i in range(3)]
    f = font('title', 150); sp = 46; tot = sum(f.getlength(w) for _, w in nums) + sp * 2; x = (W - tot) / 2
    for ts_, w in nums:
        bt = t - ts_ + 0.04
        if bt >= 0:
            fi = int(bt * FPS); kind = ['serif', 'sub_light', 'title', 'serif'][(fi // 2) % 4] if fi < 6 else 'title'
            ff = font(kind, 150 if kind == 'title' else 128); sc = 1 + 0.6 * (1 - ease(bt / 0.15))
            cv = Image.new('RGBA', (int(f.getlength(w) + 80), 240), (0, 0, 0, 0))
            ImageDraw.Draw(cv).text((40, 10), w, font=ff, fill=CREAM + (int(255 * clamp(bt / 0.06) * (1 - out)),))
            if sc > 1.01: cv = cv.resize((int(cv.width * sc), int(cv.height * sc)), Image.BICUBIC)
            layer.alpha_composite(cv, (int(x + f.getlength(w) / 2 - cv.width / 2), int(cy - 95 - cv.height / 2)))
        x += f.getlength(w) + sp
    bt = t - ws[3][0] + 0.04
    if bt > 0:
        f2 = font('title', 92); tw = f2.getlength(tail); core = tail.rstrip('.'); bw = f2.getlength(core); bb = f2.getbbox(core)
        cv = Image.new('RGBA', (int(tw + 60), 170), (0, 0, 0, 0)); d = ImageDraw.Draw(cv); x0 = 30
        r = ease(bt / 0.3); a = int(255 * (1 - out))
        rect = (x0 - 14, 20 + bb[1] - 12, x0 - 14 + (bw + 28) * r, 20 + bb[3] + 12)
        d.rectangle(rect, fill=ORANGE + (a,))
        txt = Image.new('RGBA', cv.size, (0, 0, 0, 0)); ImageDraw.Draw(txt).text((x0, 20), tail, font=f2, fill=CREAM + (a,))
        nv = Image.new('RGBA', cv.size, (0, 0, 0, 0)); ImageDraw.Draw(nv).text((x0, 20), tail, font=f2, fill=NAVYD + (a,))
        m = Image.new('L', cv.size, 0); ImageDraw.Draw(m).rectangle((rect[0], 0, rect[2], cv.height), fill=255)
        cv.alpha_composite(Image.composite(nv, txt, m))
        lift = (1 - ease(bt / 0.25)) * 30
        layer.alpha_composite(cv, (int((W - cv.width) / 2), int(cy + 70 - cv.height / 2 + lift)))

def numeral(layer, num, lt, span, ny):
    f = font('title_bold', 460); r = ease(lt / 0.45); out = ease((lt - (span - 5 / FPS)) / (5 / FPS))
    a = int(150 * r * (1 - out))
    if a <= 0: return
    x = W - 90 - f.getlength(num) + (1 - r) * 260 - lt * 20
    ImageDraw.Draw(layer).text((x, ny), num, font=f, fill=(0, 0, 0, 0), stroke_width=4, stroke_fill=CREAM + (a,))

def band(cy, hgt, strength):
    ys = np.arange(H); return (np.clip(1 - np.abs(ys - cy) / hgt, 0, 1) ** 1.5 * strength).astype(np.float32)[:, None, None]

CAPS = P['captions']; CY = P.get('caption_y', 520); CSIZE = P.get('caption_size', 74)
rng = np.random.default_rng(3)
GRAIN = [rng.normal(0, 6, (H // 2, W // 2, 1)).astype(np.float32).repeat(2, 0).repeat(2, 1) for _ in range(6)]
END = P['end']; TOTAL = TEND + END['transition'] + END['hold']; FILL = np.array(color(END.get('fill', 'navy')), np.float32)

def render_frame(fi):
    t = fi / FPS
    if t >= TEND + END['transition']:
        return np.clip(FILL + np.zeros((H, W, 3), np.float32), 0, 255).astype(np.uint8)
    arr = scene(min(t, TEND + END['transition'] - 1 / FPS))
    k = seg_at(t); s = SEG[k]
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    cap = next((c for c in CAPS if c['t0'] <= t < c['t1']), None)
    if cap:
        bf = min(1, (t - cap['t0']) / 0.2)
        arr = arr * (1 - band(CY, 270, 0.42 if s['mode'] != 'talk' else 0.3) * bf)
        if cap.get('style') == 'numbers': numbers_moment(layer, cap, t, CY)
        else: caption(layer, cap, t - cap['t0'], cap['t1'] - cap['t0'], CY, CSIZE)
    if s.get('num'): numeral(layer, s['num'], t - s['t0'], s['t1'] - s['t0'], s.get('num_y', 1000))
    sh = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    sh.putalpha(layer.getchannel('A').filter(ImageFilter.GaussianBlur(10)).point(lambda v: min(255, int(v * 1.1))))
    la = np.asarray(Image.alpha_composite(sh, layer), np.float32); al = la[..., 3:4] / 255
    arr = arr * (1 - al) + la[..., :3] * al
    if LOOK['grain']: arr = arr + GRAIN[fi % 6]
    # end: everything softly defocuses, eases forward and dissolves into the clean brand slot
    if t > TEND:
        r = easeio((t - TEND) / END['transition'])
        arr = zoom(blur(arr, 60 * r), 1 + 0.05 * r) * (1 - r) + FILL * r
    return np.clip(arr, 0, 255).astype(np.uint8)

if STILLS:
    for ts_ in STILLS: Image.fromarray(render_frame(int(round(ts_ * FPS)))).save(f'{OUT}_{ts_:05.2f}.png')
    sys.exit()

NF = int(round(TOTAL * FPS)); print(f'{TOTAL:.2f}s, {NF} frames')
tmp = OUT + '.video.mp4'
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS),
                        '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', tmp], stdin=subprocess.PIPE)
for fi in range(NF):
    enc.stdin.write(render_frame(fi).tobytes())
    if fi % 150 == 0: print(f'{fi / FPS:.1f}s', flush=True)
enc.stdin.close(); enc.wait()
# voice: NATURAL by default - one static gain + a transparent peak limiter that only catches rare peaks, soft
# fade in/out, silence under the end slot. No denoise/compression/EQ: those made the voice sound "underwater".
# (audio.process = "clean" restores the old high-pass + denoise + compressor + loudnorm chain.)
A = P['audio']; fo = TEND - 0.1
if A.get('process', 'natural') == 'clean':
    af = (f"highpass=f=80,afftdn=nf=-30,acompressor=threshold=-20dB:ratio=2.5:attack=8:release=120:makeup=2,"
          f"loudnorm=I=-14:TP=-1.5:LRA=9,afade=t=in:st=0:d=0.12,afade=t=out:st={fo:.2f}:d=0.7,apad")
else:
    af = (f"volume={A.get('gain_db', 0)}dB,alimiter=limit={10 ** (-1.5 / 20):.4f}:attack=2:release=40:level=disabled,"
          f"afade=t=in:st=0:d=0.05,afade=t=out:st={fo:.2f}:d=0.7,apad")
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', tmp, '-i', src_path(A['src']), '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                '-af', af, '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', f'{TOTAL:.3f}', OUT], check=True)
os.remove(tmp); print('done', OUT)
