#!/usr/bin/env bash
# Download a reference reel (TikTok/IG/YouTube) and break it down for technique analysis.
# Usage: analyze_reference.sh <url-or-local-file> <outdir>
# Output: ref.mp4, cuts.txt (scene-change timestamps), sheet*.jpg (2 fps contact sheets),
#         open.jpg (first 2s at 6 fps — title treatment), and per-cut strips in cuts/.
set -euo pipefail
SRC="$1"; OUT="$2"; mkdir -p "$OUT/cuts"
if [[ -f "$SRC" ]]; then cp "$SRC" "$OUT/ref.mp4"; else
  command -v yt-dlp >/dev/null || pip install -q yt-dlp
  yt-dlp -q -o "$OUT/ref.mp4" "$SRC"
fi
ffprobe -v error -show_entries format=duration:stream=codec_type,width,height,r_frame_rate -of compact "$OUT/ref.mp4"
ffmpeg -hide_banner -i "$OUT/ref.mp4" -vf "select='gt(scene,0.25)',showinfo" -an -f null - 2>&1 \
  | grep -o 'pts_time:[0-9.]*' | cut -d: -f2 > "$OUT/cuts.txt" || true
echo "cuts: $(wc -l < "$OUT/cuts.txt")"; tr '\n' ' ' < "$OUT/cuts.txt"; echo
ffmpeg -v error -y -i "$OUT/ref.mp4" -vf "fps=2,scale=180:-1,tile=8x4" "$OUT/sheet%02d.jpg"
ffmpeg -v error -y -i "$OUT/ref.mp4" -vf "select='lt(t,2)',fps=6,scale=240:-1,tile=6x2" -frames:v 1 "$OUT/open.jpg"
i=0; while read -r c; do i=$((i+1)); s=$(awk -v c="$c" 'BEGIN{s=c-0.4; if(s<0)s=0; print s}')
  ffmpeg -nostdin -v error -y -ss "$s" -t 0.9 -i "$OUT/ref.mp4" -vf "fps=12,scale=160:-1,tile=11x1" -frames:v 1 "$OUT/cuts/cut$(printf %02d $i).jpg"
done < "$OUT/cuts.txt"
ls "$OUT"
