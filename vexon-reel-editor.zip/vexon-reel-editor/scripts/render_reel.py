#!/usr/bin/env python3
"""Render a VEXON-style 9:16 reel from a plan JSON.

Usage:
  render_reel.py plan.json out.mp4                 # full render (video only, CRF 17 intermediate)
  render_reel.py plan.json stills_prefix --stills 0.5,4.9,12.0   # PNG stills at those seconds

Requires: ffmpeg on PATH, Python 3 with numpy + Pillow.
See SKILL.md and examples/*.plan.json for the plan format.
"""
import json, math, os, random, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)

# ---------------------------------------------------------------- config
plan_path, OUT = sys.argv[1], sys.argv[2]
STILLS = None
if '--stills' in sys.argv:
    STILLS = [float(x) for x in sys.argv[sys.argv.index('--stills') + 1].split(',')]
P = json.load(open(plan_path))
PLAN_DIR = os.path.dirname(os.path.abspath(plan_path))

W, H = P.get('size', [1080, 1920])
FPS = P.get('fps', 30)
BPM = P.get('bpm', 140)
BEAT = 60 / BPM
BAR = 4 * BEAT

def hex2rgb(h): h = h.lstrip('#'); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
BR = {'orange': '#ff7a1a', 'gold': '#f7b137', 'cream': '#fbf7ef', 'navy': '#0b1525', 'white': '#ffffff'}
BR.update(P.get('brand_colors', {}))
COL = {k: hex2rgb(v) for k, v in BR.items()}
ORANGE, CREAM, NAVYD = COL['orange'], COL['cream'], COL['navy']
def color(name): return COL[name] if name in COL else hex2rgb(name)

FONT_DIR = P.get('fonts_dir') or os.path.join(SKILL, 'assets', 'fonts')
TITLE_FONT = os.path.join(FONT_DIR, P.get('title_font', 'Oswald.ttf'))
SUB_FONT = os.path.join(FONT_DIR, P.get('subtitle_font', 'PublicSans.ttf'))
SERIF = P.get('serif_font', '/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf')

LOOK = {'grade': True, 'grain': True, 'beat_pulse': True, 'card_border': False}
LOOK.update(P.get('look', {}))
PULSE = LOOK.get('pulse', 0.022)
TEXT_ONLY = bool(os.environ.get('VEXON_TEXT_ONLY'))  # debug: overlays on black, to measure safe zones
if TEXT_ONLY: LOOK['grain'] = False
TAIL = 24  # extra frames so soft transitions can overlap the next shot

def src_path(key):
    if key is None: return None
    p = P['sources'].get(key, key)
    return p if os.path.isabs(p) else os.path.join(PLAN_DIR, p)

_fc = {}
def font(kind, size):
    k = (kind, size)
    if k in _fc: return _fc[k]
    spec = {'title': (TITLE_FONT, 650), 'title_bold': (TITLE_FONT, 700), 'sub': (SUB_FONT, 800),
            'sub_medium': (SUB_FONT, 600), 'sub_light': (SUB_FONT, 300), 'serif': (SERIF, None)}[kind]
    f = ImageFont.truetype(spec[0], size)
    if spec[1]:
        try: f.set_variation_by_axes([spec[1]])
        except Exception: pass
    _fc[k] = f
    return f

# ---------------------------------------------------------------- timeline
SHOTS = P['shots']
t = 0.0
for s in SHOTS:
    s['dur'] = s['secs'] if 'secs' in s else (s['bars'] * BAR if 'bars' in s else s.get('beats', 1) * BEAT)
    s['t0'] = t; t += s['dur']; s['t1'] = t
    s.setdefault('tin', 'cut'); s.setdefault('kind', 'line' if 'text' in s else ('end' if s.get('src') is None else 'plain'))
    if 'text' in s:
        hl = [h.lower() for h in s.get('highlight', [])]
        s['_words'] = [(w, any(h in w.lower().strip('.,?!…') for h in hl)) for w in s['text'].split()]
TOTAL = t

# ---------------------------------------------------------------- footage
GRADE = ("eq=contrast=1.10:brightness={b}:saturation=0.88,"
         "colorbalance=rs=-0.04:bs=0.06:rm=0.03:bm=-0.02:rh=0.08:gh=0.02:bh=-0.07,"
         "vignette=angle=PI/4.5")

class Reader:
    """Streams graded, 9:16-cropped frames of one shot from ffmpeg."""
    def __init__(self, s): self.s = s; self.p = None; self.n = 0; self.last = None; self.base = 0
    def start(self, at=0):
        s = self.s; sp = s.get('speed', 1.0)
        nfr = int(round(s['dur'] * FPS)) + 3 + TAIL
        cx, cy = s.get('cx', 0.5), s.get('cy', 0.5)
        vf = ('transpose=2,' if s.get('rot') else '') + f"setpts=(PTS-STARTPTS)/{sp},fps={FPS}," + \
             f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos," + \
             f"crop={W}:{H}:(iw-{W})*{cx}:(ih-{H})*{cy}"
        if LOOK['grade']: vf += ',' + GRADE.format(b=s.get('bright', -0.02))
        self.base = at
        self.p = subprocess.Popen(['ffmpeg', '-v', 'quiet', '-ss', str(s['ss'] + at / FPS * sp), '-i', src_path(s['src']),
                                   '-an', '-vf', vf, '-frames:v', str(nfr), '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
                                  stdout=subprocess.PIPE)
        self.n = at
    def frame(self, i):
        if self.p is None or i < self.base: self.start(i if STILLS else 0)
        while self.n <= i:
            b = self.p.stdout.read(W * H * 3)
            if len(b) < W * H * 3: break
            self.last = np.frombuffer(b, np.uint8).reshape(H, W, 3); self.n += 1
        if self.last is None: self.last = np.zeros((H, W, 3), np.uint8)
        return self.last

readers = [Reader(s) if s.get('src') else None for s in SHOTS]

def clamp(x): return min(max(x, 0.0), 1.0)
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def easeio(x): x = clamp(x); return x * x * (3 - 2 * x)
def back(x): x = clamp(x); c = 1.7; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2

HITS = ('flash', 'cutout', 'whip', 'panels', 'punch', 'hit')

def shot_zoom(k, t):
    s = SHOTS[k]; lt = t - s['t0']
    z0, z1 = s.get('z', [1.04, 1.04])
    z = z0 + (z1 - z0) * easeio(lt / s['dur'])
    if s['kind'] == 'burst':
        z = 1.14 - 0.12 * ease(lt / s['dur'])
    elif LOOK['beat_pulse']:
        ph = (t % (2 * BEAT)) / BEAT
        z *= 1 + PULSE * math.exp(-ph * 5)
    return z

def shot_image(k, t):
    s = SHOTS[k]; lt = t - s['t0']
    if TEXT_ONLY: return Image.new('RGB', (W, H)), shot_zoom(k, t)
    img = Image.fromarray(readers[k].frame(max(0, int(round(lt * FPS)))))
    z = shot_zoom(k, t); blur = 0
    nxt = SHOTS[k + 1] if k + 1 < len(SHOTS) else None
    if nxt and nxt['tin'] == 'punch':
        r = (lt - (s['dur'] - 5 / FPS)) / (5 / FPS)
        if r > 0: z *= 1 + 0.35 * r * r; blur = 14 * r
    if s['tin'] == 'punch':
        r = 1 - lt / (6 / FPS)
        if r > 0: z *= 1 + 0.25 * r * r; blur = max(blur, 14 * r)
    if abs(z - 1) > 1e-3:
        cw, ch = W / z, H / z; zc = s.get('zc', [W / 2, H / 2])
        x0 = min(max(zc[0] - cw / 2, 0), W - cw) if z > 1 else (W - cw) / 2
        y0 = min(max(zc[1] - ch / 2, 0), H - ch) if z > 1 else (H - ch) / 2
        img = img.resize((W, H), Image.BICUBIC, box=(x0, y0, x0 + cw, y0 + ch))
    if blur > 0.5: img = img.filter(ImageFilter.GaussianBlur(blur))
    return img, z

def xf(p, z): return ((p[0] - W / 2) * z + W / 2, (p[1] - H / 2) * z + H / 2)

# ---------------------------------------------------------------- transitions
JAG = {}
def jag_mask(step, nsteps, seed):
    key = (step, seed)
    if key in JAG: return JAG[key]
    rnd = random.Random(seed * 100 + step)
    level = H * (1.05 - 1.35 * ease((step + 1) / nsteps))
    pts = []; n = 14
    for j in range(n + 1):
        x = W * j / n + (rnd.uniform(-30, 30) if 0 < j < n else 0)
        pts.append((x, level + rnd.uniform(-220, 220) + 160 * math.sin(j * 0.9 + seed)))
    edge = [(-10, pts[0][1])] + pts[1:-1] + [(W + 10, pts[-1][1])]
    m = Image.new('L', (W, H), 0); ImageDraw.Draw(m).polygon([(0, H + 50)] + edge + [(W + 10, H + 50)], fill=255)
    o = Image.new('L', (W, H), 0); ImageDraw.Draw(o).line(edge, fill=255, width=9, joint='curve')
    JAG[key] = (np.asarray(m, np.float32)[..., None] / 255, np.asarray(o, np.float32)[..., None] / 255)
    return JAG[key]

def hblur(a, amt):
    if amt < 2: return a
    out = np.zeros_like(a)
    for j in range(7): out += np.roll(a, int((j - 3) * amt / 7), axis=1)
    return out / 7

def shift(a, dx):
    dx = int(dx); out = np.zeros_like(a)
    if 0 <= dx < W: out[:, dx:] = a[:, :W - dx]
    elif -W < dx < 0: out[:, :W + dx] = a[:, -dx:]
    return out

# ---------------------------------------------------------------- text
def layout(words, fnt, maxw):
    lines, cur = [], []; sp = fnt.getlength(' ')
    for w in words:
        test = cur + [w]
        if sum(fnt.getlength(x[0]) for x in test) + sp * (len(test) - 1) > maxw and cur:
            lines.append(cur); cur = [w]
        else: cur = test
    if cur: lines.append(cur)
    return lines

def text_block(layer, words, lt, span, cy, size, maxw, box_at, top=None, reveal=0.32, stagger=0.07, no_out=False, lh_k=1.12):
    """Uppercase kinetic text: lines mask-wipe up; key words get an orange box wiping in behind them
    (trailing punctuation stays outside the box); lines are balanced so no word is left alone."""
    fnt = font('title', size)
    txt = [(w.upper(), h) for w, h in words]
    n0 = len(layout(txt, fnt, maxw)); mw = maxw
    while mw > 300 and len(layout(txt, fnt, mw - 10)) == n0: mw -= 10
    lines = layout(txt, fnt, mw)
    lh = int(size * lh_k); total = lh * len(lines); y0 = cy - total / 2 if top is None else top
    sp = fnt.getlength(' ')
    out_r = 0 if no_out else ease((lt - (span - 5 / FPS)) / (5 / FPS))
    for li, line in enumerate(lines):
        lw = sum(fnt.getlength(w) for w, _ in line) + sp * (len(line) - 1)
        x = (W - lw) / 2; ly = y0 + li * lh
        r = ease((lt - li * stagger) / reveal)
        if r <= 0: continue
        CH = int(size * 1.5); lc = Image.new('RGBA', (W, CH), (0, 0, 0, 0)); ld = ImageDraw.Draw(lc)
        off = max((1 - r) * (lh + 10) - out_r * (lh + 10), -(lh + 10))
        bx = x
        for w, hl in line:
            ww = fnt.getlength(w)
            br = ease((lt - box_at) / 0.25) if hl else 0
            if br > 0:
                core = w.rstrip('.,?!…'); bw = fnt.getlength(core); bb = fnt.getbbox(core)
                ld.rectangle((bx - 12, 6 + bb[1] - 10, bx - 12 + (bw + 24) * br, 6 + bb[3] + 10), fill=ORANGE + (255,))
            ld.text((bx, 6), w, font=fnt, fill=CREAM + (255,))
            if br > 0:
                nv = Image.new('RGBA', lc.size, (0, 0, 0, 0)); ImageDraw.Draw(nv).text((bx, 6), w, font=fnt, fill=NAVYD + (255,))
                m = Image.new('L', lc.size, 0); ImageDraw.Draw(m).rectangle((bx - 12, 0, bx - 12 + (bw + 24) * br, CH), fill=255)
                lc.paste(nv, (0, 0), Image.composite(nv, Image.new('RGBA', lc.size, (0, 0, 0, 0)), m).getchannel('A'))
            bx += ww + sp
        sh = Image.new('RGBA', lc.size, (0, 0, 0, 0)); sh.paste(lc, (0, int(off)))
        layer.alpha_composite(sh, (0, int(ly - 6)))
    return y0, total

def numeral(layer, num, lt, span, ny, no_out=False):
    """Giant outlined number; slides in from the right and drifts (parallax)."""
    f = font('title_bold', 560)
    r = ease(lt / 0.45); out = 0 if no_out else ease((lt - (span - 5 / FPS)) / (5 / FPS))
    a = int(150 * r * (1 - out))
    if a <= 0: return
    x = W - 40 - f.getlength(num) + (1 - r) * 300 - lt * 25
    ImageDraw.Draw(layer).text((x, ny), num, font=f, fill=(0, 0, 0, 0), stroke_width=4, stroke_fill=CREAM + (a,))

def tag(d, x, y, text, a):
    f = font('sub', 30); w = f.getlength(text)
    d.rectangle((x, y, x + w + 36, y + 50), fill=ORANGE + (a,))
    d.text((x + 18, y + 7), text, font=f, fill=NAVYD + (a,))

def callout(layer, fx, lt, span, z):
    """Motion-graphic callouts locked to the footage: brackets / scan / rings (+ label tag)."""
    d = ImageDraw.Draw(layer)
    out = 1 - ease((lt - (span - 5 / FPS)) / (5 / FPS))
    if fx['kind'] in ('brackets', 'scan'):
        x0, y0 = xf(fx['box'][:2], z); x1, y1 = xf(fx['box'][2:], z)
        r = back((lt - BEAT) / 0.35)
        if r <= 0: return
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2; s = 1 + 0.25 * (1 - r)
        x0, x1 = cx + (x0 - cx) * s, cx + (x1 - cx) * s; y0, y1 = cy + (y0 - cy) * s, cy + (y1 - cy) * s
        a = int(255 * clamp(r) * out); L = 70
        for (px, py, sx, sy) in [(x0, y0, 1, 1), (x1, y0, -1, 1), (x0, y1, 1, -1), (x1, y1, -1, -1)]:
            d.line([(px, py + sy * L), (px, py), (px + sx * L, py)], fill=CREAM + (a,), width=7)
        if fx['kind'] == 'scan':
            ph = ((lt - BEAT) % (4 * BEAT)) / (4 * BEAT); sy = y0 + (y1 - y0) * ph
            d.rectangle((x0 + 12, sy - 2, x1 - 12, sy + 2), fill=ORANGE + (int(a * 0.9),))
            for g in range(1, 8):
                d.rectangle((x0 + 12, sy - 2 - g * 9, x1 - 12, sy - 2 - (g - 1) * 9), fill=ORANGE + (int(a * 0.12 * (8 - g) / 7),))
        tr = ease((lt - BEAT - 0.15) / 0.25)
        if tr > 0 and fx.get('tag'): tag(d, x0, y0 - 66 + (1 - tr) * 20, fx['tag'], int(255 * tr * out))
    elif fx['kind'] == 'rings':
        c = xf(fx['c'], z); st = BEAT
        if lt < st: return
        for k in range(3):
            v = (lt - st) / BEAT - k * 0.33
            if v < 0: continue
            ph = v % 1.0; rad = 70 + 230 * ease(ph)
            d.ellipse((c[0] - rad, c[1] - rad, c[0] + rad, c[1] + rad), outline=ORANGE + (int(220 * (1 - ph) * out),), width=6)
        r = back((lt - st) / 0.3)
        d.ellipse((c[0] - 14 * r, c[1] - 14 * r, c[0] + 14 * r, c[1] + 14 * r), fill=ORANGE + (int(255 * out),))
        tr = ease((lt - st - 0.15) / 0.25)
        if tr > 0 and fx.get('tag'):
            d.line([(c[0] + 14, c[1] - 14), (c[0] + 120, c[1] - 180)], fill=CREAM + (int(230 * tr * out),), width=4)
            tag(d, c[0] + 120, c[1] - 230 + (1 - tr) * 20, fx['tag'], int(255 * tr * out))

FLICK = ['serif', 'sub_light', 'title', 'serif', 'sub']
def hook_title(layer, words, lt, span):
    """Approved hook: each word group SLAMS in on its beat (scale 1.6 -> 1) with a 4-step font flicker
    (serif / Public Sans light / Oswald / serif / Public Sans), then locks to Oswald. No underline."""
    out = ease((lt - (span - 4 / FPS)) / (4 / FPS))
    for wd in words:
        bt = lt - wd['beat'] * BEAT
        if bt < 0: continue
        fi = int(bt * FPS)
        kind = FLICK[(fi // 2) % len(FLICK)] if fi < 8 else 'title'
        sz = int(wd['size'] * (1.0 if kind == 'title' else 0.82))
        f = font(kind, sz); tw = f.getlength(wd['text'])
        sc = 1 + 0.6 * (1 - ease(bt / 0.16))
        c = Image.new('RGBA', (int(tw + 40), int(sz * 1.5)), (0, 0, 0, 0))
        ImageDraw.Draw(c).text((20, 0), wd['text'], font=f, fill=color(wd.get('color', 'cream')) + (int(255 * clamp(bt / 0.08) * (1 - out)),))
        if sc > 1.01: c = c.resize((int(c.width * sc), int(c.height * sc)), Image.BICUBIC)
        layer.alpha_composite(c, (int((W - c.width) / 2), int(wd['y'] - c.height / 2)))

def band(cy, hgt, strength):
    ys = np.arange(H)
    return (np.clip(1 - np.abs(ys - cy) / hgt, 0, 1) ** 1.5 * strength).astype(np.float32)[:, None, None]

CARD = None
if LOOK['card_border']:  # rounded "film card" frame — OFF by default (client asked for clean full-bleed)
    cm = Image.new('L', (W * 2, H * 2), 0)
    ImageDraw.Draw(cm).rounded_rectangle((36, 36, W * 2 - 36, H * 2 - 36), 116, fill=255)
    CARD = np.asarray(cm.resize((W, H), Image.LANCZOS), np.float32)[..., None] / 255
rng = np.random.default_rng(3)
GRAIN = [rng.normal(0, 7, (H // 2, W // 2, 1)).astype(np.float32).repeat(2, 0).repeat(2, 1) for _ in range(6)]

def shot_at(t):
    for k, s in enumerate(SHOTS):
        if s['t0'] <= t < s['t1']: return k
    return len(SHOTS) - 1

def text_span(k):
    s = SHOTS[k]
    if s.get('cont'): return text_span(k - 1)
    if s['kind'] not in ('title', 'line', 'cta'): return None
    end = SHOTS[k + s.get('text_span', 1) - 1]['t1']
    return (k, s['t0'], end)

SOFT = {'dissolve': 10, 'slide': 10, 'wipe': 12, 'dip': 16}   # editorial transitions (no shake / RGB split)

def soft_next(k):
    """True when the shot after k enters with a soft transition, so k's text should hold (no exit) and
    ride the transition instead."""
    return k + 1 < len(SHOTS) and SHOTS[k + 1]['tin'] in SOFT

def shot_full(k, t, fi):
    """Footage + legacy transitions + per-shot overlays (text, numbers, callouts) for shot k at time t.
    t may run past the shot's end (used as the outgoing side of a soft transition)."""
    s = SHOTS[k]; lt = t - s['t0']; fr = lt * FPS
    if s.get('src') is None:
        arr = np.zeros((H, W, 3), np.float32); arr[:] = color(s.get('fill', 'navy')); z = 1
        return arr
    img, z = shot_image(k, t); arr = np.asarray(img, np.float32)

    def prev(): return np.asarray(shot_image(k - 1, s['t0'] - 1 / FPS)[0], np.float32)
    if s['tin'] == 'cutout' and fr < 10:
        m, o = jag_mask(int(fr) // 2, 5, k)
        arr = prev() * (1 - m) + arr * m; arr = arr * (1 - o) + 255 * o
    if s['tin'] == 'whip' and fr < 7:
        r = ease(fr / 7); off = int(-r * W); blur = 160 * (1 - r) + 20
        arr = shift(hblur(prev(), blur), off) + shift(hblur(arr, blur * (1 - r)), off + W)
    if s['tin'] == 'panels' and fr < 10:
        new = arr; arr = prev().copy(); n = 4; pw = W // n
        for j in range(n):
            r = ease((fr - j * 1.4) / 5)
            if r <= 0: continue
            dy = int((1 - r) * -H); seg = new[:, j * pw:(j + 1) * pw]
            if dy == 0: arr[:, j * pw:(j + 1) * pw] = seg
            else:
                arr[0:H + dy, j * pw:(j + 1) * pw] = seg[-dy:]
                arr[max(0, H + dy - 10):H + dy, j * pw:(j + 1) * pw] = ORANGE

    # camera shake + RGB split on hits
    hitr = max(0, 1 - fr / 6) if s['tin'] in HITS and s['kind'] != 'end' else 0
    if s['kind'] == 'burst': hitr = max(hitr, 0.8 * max(0, 1 - fr / 4))
    if hitr > 0:
        rr = random.Random(fi)
        dx = int(rr.uniform(-1, 1) * 22 * hitr); dy = int(rr.uniform(-1, 1) * 22 * hitr)
        arr = np.roll(arr, (dy, dx), axis=(0, 1))
        sp = int(14 * hitr)
        if sp:
            arr = arr.copy(); arr[..., 0] = np.roll(arr[..., 0], sp, 1); arr[..., 2] = np.roll(arr[..., 2], -sp, 1)

    if s.get('band'):   # extra legibility band for shots without their own text (e.g. the header intro)
        by, bh, bs = s['band']; arr = arr * (1 - band(by, bh, bs) * min(1, lt / 0.25))
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    span = text_span(k)
    if span:
        sk, a0, a1 = span; ts = SHOTS[sk]; tl = t - a0
        hold = soft_next(sk + ts.get('text_span', 1) - 1)
        bf = min(1, tl / 0.25) * (1 if hold else clamp((a1 - t) / 0.2))
        if ts['kind'] == 'title':
            arr = arr * (1 - band(ts.get('band_y', 820), 560, 0.5) * bf)
            hook_title(layer, ts['title_words'], tl, 1e9 if hold else a1 - a0)
        elif ts['kind'] == 'cta':
            cy = ts.get('ty', 900)
            arr = arr * (1 - band(cy + 50, 600, 0.55) * bf)
            text_block(layer, ts['_words'], tl, a1 - a0, cy, ts.get('size', 96), 900, BEAT, no_out=hold)
        else:
            cy = ts.get('ty', 1130)
            arr = arr * (1 - band(ts.get('band_y', cy), ts.get('band_h', 520), ts.get('band_s', 0.55)) * bf)
            if ts.get('num'): numeral(layer, ts['num'], tl, a1 - a0, ts.get('num_y', 150), no_out=hold)
            n = len(ts['_words']); size = ts.get('size', 92 if n <= 9 else (80 if n <= 14 else 70))
            tlay = Image.new('RGBA', (W, H), (0, 0, 0, 0)) if ts.get('pop') else layer
            text_block(tlay, ts['_words'], tl - ts.get('text_delay', 0), a1 - a0, cy, size, ts.get('maxw', 940),
                       ts.get('box_beats', 2) * BEAT, top=ts.get('ttop'), reveal=ts.get('reveal', 0.32),
                       stagger=ts.get('stagger', 0.07), no_out=hold, lh_k=ts.get('lh_k', 1.12))
            if ts.get('pop'):   # settle from a slightly larger scale: emphasis without flash
                sc = 1 + ts['pop'] * (1 - ease((tl - ts.get('text_delay', 0)) / 0.55))
                if sc > 1.002:
                    bb = tlay.getbbox()
                    if bb:
                        crop = tlay.crop(bb); nw, nh = int(crop.width * sc), int(crop.height * sc)
                        ccx, ccy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
                        tlay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
                        tlay.alpha_composite(crop.resize((nw, nh), Image.BICUBIC), (int(ccx - nw / 2), int(ccy - nh / 2)))
                layer.alpha_composite(tlay)
    if s.get('fx'): callout(layer, s['fx'], lt, s['dur'], z)
    return composite(arr, layer)

def composite(arr, layer):
    """Lay an RGBA overlay on the frame with the house soft drop shadow."""
    if layer.getbbox() is None: return arr
    sh = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    sh.putalpha(layer.getchannel('A').filter(ImageFilter.GaussianBlur(12)).point(lambda v: min(255, int(v * 1.2))))
    la = np.asarray(Image.alpha_composite(sh, layer), np.float32); al = la[..., 3:4] / 255
    return arr * (1 - al) + la[..., :3] * al

def vblur(a, amt):
    if amt < 2: return a
    out = np.zeros_like(a)
    for j in range(5): out += np.roll(a, int((j - 2) * amt / 5), axis=0)
    return out / 5

def soft_transition(kind, prv, cur, r):
    if kind == 'dissolve':
        a = easeio(r); return prv * (1 - a) + cur * a
    if kind == 'dip':
        nv = np.array(NAVYD, np.float32)
        if r < 0.5: a = easeio(r * 2); return prv * (1 - a) + nv * a
        a = easeio(r * 2 - 1); return nv * (1 - a) + cur * a
    if kind == 'slide':   # vertical push: new shot pushes the old one up, light motion blur
        e = easeio(r); off = int(round(e * H)); v = 6 * e * (1 - e) * H / 10
        out = np.empty_like(cur)
        if off < H: out[:H - off] = vblur(prv, v)[off:]
        if off > 0: out[H - off:] = vblur(cur, v)[:off]
        return out
    if kind == 'wipe':    # soft diagonal wipe with a thin orange leading edge
        e = easeio(r); xs = np.arange(W)[None, :, None]; ys = np.arange(H)[:, None, None]
        edge = -260 + e * (W + 520) + (ys - H / 2) * 0.2
        m = np.clip((edge - xs) / 60 + 0.5, 0, 1)
        out = prv * (1 - m) + cur * m
        ln = np.clip(1 - np.abs(edge - xs) / 4, 0, 1) * (0 < r < 1)
        return out * (1 - ln) + np.array(ORANGE, np.float32) * ln
    return cur

HDR = P.get('header')
if HDR:
    _hs = [k for k, s in enumerate(SHOTS) if s.get('header')]
    _hi = [k for k, s in enumerate(SHOTS) if s.get('header_intro')]
    HDR_T = (SHOTS[_hi[0]]['t0'] if _hi else SHOTS[_hs[0]]['t0'], SHOTS[_hs[0]]['t0'], SHOTS[_hs[-1]]['t1'])

def header_layer(t):
    """Persistent section label (e.g. "IT'S:"): reveals big on its intro shot, glides up and shrinks into a
    header on the first header shot, stays put (unaffected by transitions) and fades at the end."""
    if not HDR: return None
    t0, tm, te = HDR_T
    if not (t0 <= t < te): return None
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    r = ease((t - t0 - HDR.get('delay', 0.1)) / 0.45)
    if r <= 0: return layer
    m = easeio((t - tm) / 0.55) if t >= tm else 0
    size = int(HDR['big_size'] + (HDR['size'] - HDR['big_size']) * m)
    y = HDR['big_y'] + (HDR['y'] - HDR['big_y']) * m
    c0, c1 = color(HDR.get('big_color', 'cream')), color(HDR.get('color', 'orange'))
    col = tuple(int(c0[i] + (c1[i] - c0[i]) * m) for i in range(3))
    a = int(255 * clamp((te - t) / 0.3))
    f = font('title', size); tw = f.getlength(HDR['text'])
    CH = int(size * 1.45); lc = Image.new('RGBA', (W, CH), (0, 0, 0, 0))
    ImageDraw.Draw(lc).text(((W - tw) / 2, (1 - r) * CH * 0.8), HDR['text'], font=f, fill=col + (a,))
    layer.alpha_composite(lc, (0, int(y - CH / 2)))
    return layer

CAP = P.get('captions')
if CAP:
    CAPS = json.load(open(CAP['file'] if os.path.isabs(CAP['file']) else os.path.join(PLAN_DIR, CAP['file'])))
    for i, c in enumerate(CAPS):
        nxt = CAPS[i + 1]['words'][0]['s'] if i + 1 < len(CAPS) else 1e9
        c['t0'] = c['words'][0]['s'] - CAP.get('lead', 0.08)
        c['t1'] = min(nxt - CAP.get('lead', 0.08) - 0.01, c['words'][-1]['e'] + CAP.get('tail', 0.45))

def caption_layer(t):
    """Closed captions: Public Sans, cream, the word being spoken in orange; phrase-level, max 2 lines,
    fixed in the lower safe area (above Instagram's caption/UI zone), never moved by transitions."""
    if not CAP: return None, 0
    c = next((c for c in CAPS if c['t0'] <= t < c['t1']), None)
    if c is None or c.get('hide'): return None, 0   # hidden: line already on screen as big text
    size = CAP.get('size', 46); f = font('sub_medium', size); sp = f.getlength(' ')
    words = c['words']; lines = layout([(w['w'], 0) for w in words], f, CAP.get('maxw', 860))
    if len(lines) == 2 and len(lines[1]) == 1 and len(lines[0]) > 2:   # no orphan word on line 2
        lines = [lines[0][:-1], [lines[0][-1]] + lines[1]]
    a = clamp((t - c['t0']) / 0.12) * clamp((c['t1'] - t) / 0.12)
    layer = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(layer)
    lh = int(size * 1.3); cy = CAP.get('y', 1150); y0 = cy - lh * len(lines) / 2
    k = 0
    for li, line in enumerate(lines):
        lw = sum(f.getlength(w) for w, _ in line) + sp * (len(line) - 1); x = (W - lw) / 2
        for w, _ in line:
            ww = words[k]; nx = words[k + 1]['s'] if k + 1 < len(words) else 1e9
            on = ww['s'] - 0.02 <= t < min(ww['e'] + 0.05, nx - 0.02)   # exactly one word lit at a time
            col = ORANGE if on and CAP.get('active', True) else CREAM
            d.text((x, y0 + li * lh), w, font=f, fill=col + (int(255 * a),)); x += f.getlength(w) + sp; k += 1
    return layer, a

# ---------------------------------------------------------------- frame
def render_frame(fi):
    t = fi / FPS
    k = shot_at(t); s = SHOTS[k]; lt = t - s['t0']; fr = lt * FPS
    arr = shot_full(k, t, fi)
    if s['tin'] in SOFT and k > 0:
        n = s.get('tdur', SOFT[s['tin']])
        if fr < n: arr = soft_transition(s['tin'], shot_full(k - 1, t, fi), arr, (fr + 0.5) / n)
    hl = header_layer(t)
    if hl is not None: arr = composite(arr, hl)
    cl, ca = caption_layer(t)
    if cl is not None:
        arr = arr * (1 - band(CAP.get('y', 1150), CAP.get('band_h', 230), CAP.get('band_s', 0.45)) * ca)
        arr = composite(arr, cl)

    fl = 0
    if s['tin'] == 'flash': fl = max(fl, 1 - lt / (6 / FPS))
    if k + 1 < len(SHOTS) and SHOTS[k + 1]['tin'] == 'flash':
        r = (lt - (s['dur'] - 3 / FPS)) / (3 / FPS)
        if r > 0: fl = max(fl, r ** 1.5)
    if s['kind'] == 'burst' and fr < 1.5: fl = max(fl, 0.35)
    if fl > 0: arr = arr * (1 + 2.2 * fl) + 255 * 0.55 * fl

    if LOOK['grain']: arr = arr + GRAIN[fi % 6]
    if CARD is not None: arr = arr * CARD
    return np.clip(arr, 0, 255).astype(np.uint8)

# ---------------------------------------------------------------- main
if STILLS:
    for ts_ in STILLS:
        Image.fromarray(render_frame(int(round(ts_ * FPS)))).save(f'{OUT}_{ts_:05.2f}.png')
        for r in readers:
            if r: r.p = None
    sys.exit()

print(f'timeline {TOTAL:.2f}s @ {BPM} BPM')
for s in SHOTS: print(f"  {s['t0']:6.2f}-{s['t1']:6.2f}  {s.get('name', s['kind']):<20} in:{s['tin']}")
NF = int(round(TOTAL * FPS))
enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS),
                        '-i', '-', '-c:v', 'libx264', '-preset', 'medium', '-crf', '17', '-pix_fmt', 'yuv420p', OUT],
                       stdin=subprocess.PIPE)
for fi in range(NF):
    enc.stdin.write(render_frame(fi).tobytes())
    if fi % 90 == 0: print(f'{fi / FPS:.1f}s', flush=True)
enc.stdin.close(); enc.wait(); print('done', OUT)
