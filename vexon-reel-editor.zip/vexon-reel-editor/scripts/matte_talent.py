# Matte a talking-head clip with Robust Video Matting -> RGBA PNG sequence (despilled edges).
# Usage: RVM_MODEL=rvm_mobilenetv3_fp32.onnx matte_talent.py <clip> <outdir> [W H]
# Model: github.com/PeterL1n/RobustVideoMatting/releases (v1.0.0). Needs onnxruntime.
import os, subprocess, sys, numpy as np, onnxruntime as ort
from PIL import Image
src, out = sys.argv[1], sys.argv[2]
W,H = (int(sys.argv[3]), int(sys.argv[4])) if len(sys.argv) > 4 else (720, 1280)  # displayed (rotated) size
s = ort.InferenceSession('os.environ.get('RVM_MODEL','models/rvm.onnx')', providers=['CPUExecutionProvider'])
rec = [np.zeros([1,1,1,1],np.float32)]*4
dr = np.array([0.4],np.float32)
p = subprocess.Popen(['ffmpeg','-v','error','-nostdin','-i',src,'-f','rawvideo','-pix_fmt','rgb24','-'],stdout=subprocess.PIPE)
i=0
while True:
    b = p.stdout.read(W*H*3)
    if len(b)<W*H*3: break
    f = np.frombuffer(b,np.uint8).reshape(H,W,3)
    x = (f.astype(np.float32)/255).transpose(2,0,1)[None]
    fgr,pha,*rec = s.run(None,{'src':x,'r1i':rec[0],'r2i':rec[1],'r3i':rec[2],'r4i':rec[3],'downsample_ratio':dr})
    a = pha[0,0]
    fg = fgr[0].transpose(1,2,0)
    # keep original colours where solidly opaque, RVM's despilled fg toward edges
    w = np.clip((a-0.85)/0.15,0,1)[...,None]
    col = f.astype(np.float32)/255*w + fg*(1-w)
    # extra green despill on the semi-transparent fringe
    g = np.minimum(col[...,1], (col[...,0]+col[...,2])/2*1.05)
    edge = (1-w[...,0])
    col[...,1] = col[...,1]*(1-edge) + g*edge
    rgba = np.dstack([np.clip(col,0,1)*255, a[...,None]*255]).astype(np.uint8)
    Image.fromarray(rgba,'RGBA').save(f'{out}/{i:04d}.png', compress_level=1)
    i+=1
    if i%100==0: print(i, flush=True)
print('done',i)
