# Original instrumental bed for the reel (synthesised here; no samples, no third-party audio).
import numpy as np, wave
SR=44100; BPM=100; B=60/BPM; DUR=23.5; N=int(SR*DUR)
t=np.arange(N)/SR; L=np.zeros(N); R=np.zeros(N)
rng=np.random.default_rng(7)
def hz(m): return 440*2**((m-69)/12)
def lp(x,a):  # one-pole lowpass
    y=np.empty_like(x); s=0.0
    for i in range(len(x)): s+=a*(x[i]-s); y[i]=s
    return y
def add(sig,start,pan=0.0,g=1.0):
    i=int(start*SR); j=min(N,i+len(sig)); 
    if i>=N: return
    L[i:j]+=sig[:j-i]*g*(1-pan)/1.0; R[i:j]+=sig[:j-i]*g*(1+pan)/1.0
# chords (A minor, airy): Am9, Fmaj7, Cmaj7, G6  — 1 bar each
CH=[[45,57,60,64,71],[41,57,60,64,69],[48,55,59,64,67],[43,55,59,62,64]]
bar=4*B
for bi in range(int(DUR/bar)+1):
    c=CH[bi%4]; st=bi*bar; ln=bar+1.2; tt=np.arange(int(ln*SR))/SR
    env=np.minimum(1,tt/0.9)*np.minimum(1,np.maximum(0,(ln-tt)/1.2))
    pad=np.zeros_like(tt)
    for k,m in enumerate(c):
        for det in (-0.07,0.07):
            f=hz(m)*(1+det/100*3)
            pad+=sum(np.sin(2*np.pi*f*h*tt+rng.uniform(0,6))/h**1.6 for h in (1,2,3,4))
    pad=pad*env/len(c)
    add(pad*0.20,st,pan=-0.15); add(np.roll(pad,800)*0.20,st,pan=0.15)
    # arpeggio pluck on 8ths from bar 2 on
    if bi>=1:
        seq=[c[1],c[2],c[3],c[4],c[3],c[2],c[3],c[4]]
        for e,m in enumerate(seq):
            tl=np.arange(int(0.6*SR))/SR; f=hz(m+12)
            pl=(np.sin(2*np.pi*f*tl)+0.3*np.sin(4*np.pi*f*tl))*np.exp(-tl*7)
            add(pl*0.05,st+e*B/2,pan=0.35 if e%2 else -0.35)
# soft pulse (sub kick) beats 1 & 3 from 2.7 s (the "THINK AGAIN." hit) to the CTA end
kt=np.arange(int(0.5*SR))/SR; kick=np.sin(2*np.pi*(48+60*np.exp(-kt*30))*kt)*np.exp(-kt*7)
b=2.7
while b<20.6:
    add(kick*0.33,b); b+=2*B
# light shaker on 8ths
hat=lp(rng.normal(0,1,int(0.06*SR)),0.6); hat=(rng.normal(0,1,len(hat))-hat)*np.exp(-np.arange(len(hat))/SR*60)
b=2.7
while b<20.6:
    add(hat*0.025,b+B/2,pan=0.4); b+=B
# gentle swells into the title hit and the CTA, plus a low impact on each
for at in (2.7,17.2):
    ln=1.2; tl=np.arange(int(ln*SR))/SR; sw=lp(rng.normal(0,1,len(tl)),0.08)*(tl/ln)**2
    add(sw*0.12,at-ln)
    it=np.arange(int(1.5*SR))/SR; add(np.sin(2*np.pi*55*it)*np.exp(-it*3)*0.35,at)
# outro: let the last chord ring into the end slot, fade to silence
fade=np.ones(N); fs=int(21.0*SR); fade[fs:]=np.linspace(1,0,N-fs)**1.5
L*=fade; R*=fade
m=np.stack([L,R],1); m/=np.abs(m).max()*1.12
with wave.open('music.wav','wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((m*32767).astype('<i2').tobytes())
print('ok')
