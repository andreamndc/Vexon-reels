# Word-level transcript with openai-whisper (medium.en). Usage: transcribe_words.py audio.wav words.json
import json, sys, whisper
m = whisper.load_model("medium.en")
r = m.transcribe(sys.argv[1], word_timestamps=True, language="en", beam_size=5, condition_on_previous_text=False)
out=[]
for s in r["segments"]:
    print(f"[{s['start']:.2f}-{s['end']:.2f}] {s['text']}")
    for w in s["words"]: out.append({"w":w["word"].strip(),"s":round(w["start"],2),"e":round(w["end"],2)})
json.dump(out, open(sys.argv[2],"w"), indent=0)
