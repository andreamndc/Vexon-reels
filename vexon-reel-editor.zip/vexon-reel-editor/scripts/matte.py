#!/usr/bin/env python3
"""Pull a clean person matte from a talking-head clip (green screen OR any plain background) with
Robust Video Matting (ONNX, CPU). Writes <out>/alpha.mp4 (gray matte) and <out>/fgr.mp4 (foreground
colours with background spill removed), both at the source size and frame rate.
Usage: matte.py <clip> <outdir> [model.onnx] [downsample_ratio=0.25]
Model: https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx"""
import os, subprocess, sys, json
import numpy as np, onnxruntime as ort
clip, out = sys.argv[1], sys.argv[2]
model = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rvm_mobilenetv3_fp32.onnx')
dsr = float(sys.argv[4]) if len(sys.argv) > 4 else 0.25
os.makedirs(out, exist_ok=True)
pr = json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
     'stream=width,height,r_frame_rate', '-of', 'json', clip]))['streams'][0]
W, H, fps = pr['width'], pr['height'], pr['r_frame_rate']
sess = ort.InferenceSession(model, providers=['CPUExecutionProvider'])
rd = subprocess.Popen(['ffmpeg', '-v', 'error', '-i', clip, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
enc = lambda name, pix, inpix: subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', inpix, '-s', f'{W}x{H}',
     '-r', fps, '-i', '-', '-c:v', 'libx264', '-crf', '10', '-preset', 'medium', '-pix_fmt', pix, os.path.join(out, name)], stdin=subprocess.PIPE)
ea, ef = enc('alpha.mp4', 'gray', 'gray'), enc('fgr.mp4', 'yuv444p', 'rgb24')
rec = [np.zeros([1, 1, 1, 1], np.float32)] * 4; d = np.array([dsr], np.float32); n = 0
while True:
    b = rd.stdout.read(W * H * 3)
    if len(b) < W * H * 3: break
    src = np.frombuffer(b, np.uint8).reshape(H, W, 3).astype(np.float32).transpose(2, 0, 1)[None] / 255
    fgr, pha, *rec = sess.run(None, {'src': src, 'r1i': rec[0], 'r2i': rec[1], 'r3i': rec[2], 'r4i': rec[3], 'downsample_ratio': d})
    ea.stdin.write((pha[0, 0] * 255).clip(0, 255).astype(np.uint8).tobytes())
    ef.stdin.write((fgr[0].transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8).tobytes())
    n += 1
    if n % 60 == 0: print(n, flush=True)
for e in (ea, ef): e.stdin.close(); e.wait()
print('done', n)
