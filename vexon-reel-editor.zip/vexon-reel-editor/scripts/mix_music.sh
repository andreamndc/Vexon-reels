#!/usr/bin/env bash
# Lay a LICENSED music file under a talking-head render as quiet background: music sits ~-24 dB under
# the voice, is side-chain ducked further while the presenter speaks, and fades in/out smoothly.
# Usage: mix_music.sh <render_with_voice.mp4> <licensed_music> <out.mp4> [music_offset_s=0] [music_gain_db=-22]
set -euo pipefail
IN="$1"; MUS="$2"; OUT="$3"; OFF="${4:-0}"; G="${5:--22}"
D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$IN")
ffmpeg -v error -y -i "$IN" -ss "$OFF" -i "$MUS" -filter_complex \
 "[1:a]volume=${G}dB,afade=t=in:st=0:d=1.5,afade=t=out:st=$(python3 -c "print($D-2.5)"):d=2.5,apad[m];
  [0:a]asplit=2[v][sc];[m][sc]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[md];
  [v][md]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89[a]" \
 -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -movflags +faststart "$OUT"
ffprobe -v error -show_entries format=duration,size -of compact "$OUT"
