#!/usr/bin/env bash
# Show one source frame exactly as the renderer frames it (9:16 cover crop) with a 108x192 px grid,
# so you can read pixel coordinates for callouts ("box": [x0,y0,x1,y1], "c": [x,y]) and text placement.
# Each grid cell = 108 x 192 px in the 1080x1920 output.
# Usage: grid_frame.sh <clip> <seconds> <out.png> [cx=0.5] [cy=0.5] [rot=0]
set -euo pipefail
CLIP="$1"; T="$2"; OUT="$3"; CX="${4:-0.5}"; CY="${5:-0.5}"; ROT="${6:-0}"
PRE=""; [[ "$ROT" == "1" ]] && PRE="transpose=2,"
ffmpeg -v error -y -ss "$T" -i "$CLIP" -frames:v 1 -vf "${PRE}scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920:(iw-1080)*$CX:(ih-1920)*$CY,drawgrid=w=108:h=192:t=2:c=yellow@0.6,scale=540:960" "$OUT"
echo "$OUT (displayed at 50%: multiply pixel positions by 2)"
